<?php
include('../conexao.php');
$id = $_GET['id'];
$email = $_POST['email'];
$cpf = $_POST['cpf_cnpj'];
$nomecompleto = $_POST['name'];
$nascimento = $_POST['birth_date'];
$senha = $_POST['password'];
$cep = $_POST['cep'];
$endereco = $_POST['rua'];
$numero = $_POST['number'];
$complemento = $_POST['complement'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['uf'];
$telefone = $_POST['phone_number'];

// Busca informações das configurações;
$queryconf = "select * from configuracoes";
$resultadoconf = mysqli_query($conexao,$queryconf);
while($exibe = mysqli_fetch_assoc($resultadoconf)){
    $boletoativado = $exibe['boleto'];
    $apimp = $exibe['apimp'];
}
// Busca informações dos boletos:
$querybole = "select * from boletos where idproduto = {$id} & usado = 0";
$resultadobole = mysqli_query($conexao,$querybole);
$numeroboleto = mysqli_num_rows($resultadobole);

include("../conexao.php");
include("../banco.php");

$conteudo = file_get_contents('../dist/mobile/pagamento.html');

$s1 = str_replace('<form method="post" action="pagamentocc.php">','<form method="post" action="pagamentocc.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'"><input type="hidden" name="email" value="'.$email.'"><input type="hidden" name="cpf_cnpj" value="'.$cpf.'"><input type="hidden" name="name" value="'.$nomecompleto.'"><input type="hidden" name="birth_date" value="'.$nascimento.'"><input type="hidden" name="password" value="'.$senha.'"><input type="hidden" name="cep" value="'.$cep.'"><input type="hidden" name="rua" value="'.$endereco.'"><input type="hidden" name="number" value="'.$numero.'"><input type="hidden" name="complement" value="'.$complemento.'"><input type="hidden" name="bairro" value="'.$bairro.'"><input type="hidden" name="cidade" value="'.$cidade.'"><input type="hidden" name="uf" value="'.$estado.'"><input type="hidden" name="phone_number" value="'.$telefone.'">', $conteudo);
$s2 = str_replace('<form method="post" action="pagamentoleto.php">','<form method="post" action="pagamentoleto.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'"><input type="hidden" name="email" value="'.$email.'"><input type="hidden" name="cpf_cnpj" value="'.$cpf.'"><input type="hidden" name="name" value="'.$nomecompleto.'"><input type="hidden" name="birth_date" value="'.$nascimento.'"><input type="hidden" name="password" value="'.$senha.'"><input type="hidden" name="cep" value="'.$cep.'"><input type="hidden" name="rua" value="'.$endereco.'"><input type="hidden" name="number" value="'.$numero.'"><input type="hidden" name="complement" value="'.$complemento.'"><input type="hidden" name="bairro" value="'.$bairro.'"><input type="hidden" name="cidade" value="'.$cidade.'"><input type="hidden" name="uf" value="'.$estado.'"><input type="hidden" name="phone_number" value="'.$telefone.'">', $s1);
if($boletoativado == 1 & $numeroboleto >= 1 or $boletoativado == 0 & $apimp == 1){
    $s3 = $s2;
}else {
    $temp1 = str_replace('<img src="../dist/mobile/leto.png" class="flag-no-card pull-left flag flag-bankslip">','',$s2);
    $s3 = str_replace('<p class="payment-description">Pagar com Boleto bancário</p>', '', $temp1);
};
echo $s3;