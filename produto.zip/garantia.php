<?php
include("../conexao.php");
include("../functions.php");
include("../banco.php");
$id = $_GET['id'];
$dist = $_GET['dist'];
$conteudo = file_get_contents('../dist/desktop/garantia.html');
$substituicao = str_replace($conteudo,
    '<html lang="pt-br" dir="ltr" class=" js no-flexbox flexbox-legacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>        Smartphone Samsung Galaxy J5 Prime 32GB Preto - Magazine Luiza
    </title>
        <meta name="description" content="        Smartphone Samsung Galaxy J5 Prime 32GB Preto com as melhores condições você encontra no site do Magalu. Confira!
    ">
        <link rel="canonical" href="https://www.magazineluiza.com.br/produto/garantia-plus/?product=218058400&amp;marketplaceSellerId=magazineluiza&amp;productDiscountPrice=729.00&amp;productCashPrice=656.10&amp;productQuantity=10">
                
    <link type="application/opensearchdescription+xml" rel="search" href="https://www.magazineluiza.com.br/opensearch.xml">

    <link href="https://pubads.g.doubleclick.net/" rel="dns-prefetch">
    <link rel="shortcut icon" href="https://d25zlb44gqlazw.cloudfront.net/static/img/default/favicon-cc4cf323.png">

                <link rel="stylesheet" type="text/css" media="all" href="../dist/desktop/index_files/structure-1-a35bc3fb.css">
        <link rel="stylesheet" type="text/css" media="all" href="../dist/desktop/index_files/structure-2-413bb73f.css">
        <link rel="stylesheet" type="text/css" media="all" href="../dist/desktop/index_files/structure-3-57f92273.css">
        <link rel="stylesheet" type="text/css" media="all" href="../dist/desktop/index_files/checkout-09c02937.css">
    <link rel="stylesheet" type="text/css" media="all" href="../dist/desktop/index_files/warranty-804354ae.css">
    <meta name="cs:page" content="product">
    <meta name="cs:description" content="name=Smartphone Samsung Galaxy J5 Prime 32GB Preto - Dual Chip 4G Câm. 13MP + Selfie 5MP Tela 5&quot; HD, sku=218058400">
        </head><body>
        <div class="js-loading-modal blocker-load" style="display: none;">
    <img src="../dist/desktop/index_files/loading-color-1256e0c8.gif">
</div>        
                    <div class="sticky-footer-wrapper">
    <header class="wrapper-header-checkout">
    <div class="top-header-checkout">
        <div class="centralizer-header-checkout">
            <div class="laterals">
                <div class="content-header-checkout">
                    <div class="logo-top-header-checkout">
                        <a href="https://www.magazineluiza.com.br/" title="ir para a página inicial" onclick="linkHome.init();return false;">
                            <span class="logo-header-scroll">
                                <img src="../dist/desktop/index_files/logo.png" class="img-logo-header sprite-top-footer">
                            </span>
                        </a>
                    </div>
                    <div class="right-top-header-checkout">
                        <img src="../dist/desktop/index_files/segura.png" class="img-internet-footer">
                    </div>
                    <div class="middle-top-header-checkout">
                        <div class="buy-more-products">
                            
                            <a href="https://www.magazineluiza.com.br/" title="Comprar mais produtos" onclick="linkHome.init();return false;"><img src="../dist/desktop/index_files/sacola.png" class="icon-cart"> comprar mais produtos</a>
                        </div>
                        <div class="contanct-number">
                            
                            <a class="ml-imframebox ml-iframebox-click-ready" data-href="/televendas/info-televendas/" data-size="815x460" data-options="{&quot;position&quot;:&quot;center&quot;, &quot;modal&quot;:true}" title="Outros DDDs para o Televendas"><img src="../dist/desktop/index_files/telefone.png" class="icon-callcenter"> televendas (11) 3508-9900</a>
                        </div>
                        <div class="online-helper">
                            
                            <a title="Ajuda online" class="launcher"><img src="../dist/desktop/index_files/balao.png" class="icon-chat"> ajuda online</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="strip-multi-colors">
                <span class="yellow"></span>
                <span class="orange"></span>
                <span class="red"></span>
                <span class="rose"></span>
                <span class="purple"></span>
                <span class="deep-purple"></span>
                <span class="blue"></span>
                <span class="cyan"></span>
                <span class="light-green"></span>
                <span class="green"></span>
            </div>
        </div>
    </div>
    
</header>                <div class="wrapper-content-checkout">
                    <div class="checkout-wrapper">
                        
    <form name="frmBasket" id="frmBasket">
    <input type="hidden" name="basketProduct" id="basketProduct" value="218058400">
    <input type="hidden" name="basketWarranty" id="basketWarranty" value="">
    <input type="hidden" name="marketplaceSellerId" id="marketplaceSellerId" value="magazineluiza">
        </form>

<div class="header-tip">
                <div class="header-tip__box">
        <div class="header-tip__description">
            <p class="warranty__title">Saiba como proteger o seu produto por muito mais tempo!</p>
            <div class="header-tip__text">
                <p class="header-tip__product-txt">' . $nome . '<span class="color-blue"> </br>R$ '.$preco.'  à vista </span></p><img height="45px" width="60px" src="'.$imagem .'" alt="Smartphone Samsung Galaxy J5 Prime 32GB Preto - Dual Chip 4G Câm. 13MP + Selfie 5MP Tela 5&quot; HD" class="header-tip__product-img">
                
            </div>
        </div>
        <i class="warranty__sprite--arrow-top"></i>
        <img src="../dist/desktop/index_files/mulher.png" class="warranty__sprite--lu-header">
    </div>
</div>

<div class="warranty-container__banner">
</div>

<div class="warranty-container" data-product="{ &quot;category&quot; : &quot;te&quot;, &quot;subcategory&quot;: &quot;gj5p&quot;, &quot;code&quot;: &quot;218058400&quot;, &quot;name&quot;: &quot;Smartphone Samsung Galaxy J5 Prime 32GB Preto - Dual Chip 4G Câm. 13MP + Selfie 5MP Tela 5&quot; HD&quot;, &quot;price&quot;:&quot;999.0&quot; }">
                    
    <div class="warranty-wrapper">
        <div class="header-theft js-warranty-RF js-warranty-RFSQA">
            <div class="header-theft__description">
                <img class="js-warranty-RF" src="../dist/desktop/index_files/protecao_furto-5d1b2cff.png">
                <img class="js-warranty-RFSQA none" src="../dist/desktop/index_files/protecao_furto-sqa-6c0e9410.png">
                <div class="header-theft__text">
                    Pode ficar tranquilo! Nós protegemos por 1 ano os seus equipamentos portáteis contra roubo e furto qualificado<span class="acidental-crash"> e quebra acidental</span>.
                </div>
            </div>
            <div class="header-theft__option">
                <input class="header-theft__checkbox js-warranty-rf" name="roubo-e-furto" type="checkbox" id="rf-warranty">
                <div class="header-theft__box">
                    <label for="rf-warranty" class="warranty__title--option">incluir Proteção Roubo e Furto<br>qualificado <span class="acidental-crash">com quebra acidental </span>de 1 ano</label>
                    <div class="warranty__text">
                        Por apenas <strong class="color-blue"><span class="js-warranty-parcel">10</span>x de <span class="js-warranty-price">R$ 20,05</span> sem juros</strong> (à vista <span class="js-warranty-total">R$ 200,47</span>)
                    </div>
                </div>
            </div>
        </div>
        <div class="table-warranty js-warranty-GE">
                        <div class="js-control-coluns">
                <div class="table-warranty__description">
                    <img src="../dist/desktop/index_files/garantia_estendida-9e78a63f.png">
                    <div class="table-warranty__text">
                        Seu produto apresentou defeito?<br> Deixe com a gente! Seu <strong>Seguro de Garantia Estendida Original</strong> começa a valer quando acaba a garantia do fabricante, ou seja, você tem período adicional de total tranquilidade.
                    </div>
                </div>
                <div class="table-warranty__box">
                    <ul class="table-warranty__options">
                        <li><input class="table-warranty__radio without-warranty" name="ge-warranty" checked="checked" type="radio" id="no-warranty"></li>
                        <li>
                            <label for="no-warranty" class="warranty__title--center">sem garantia<br> estendida</label>
                            <p class="warranty__text--box-option">somente garantia<br> do fabricante</p>
                        </li>
                    </ul>
                    <ul class="table-warranty__options--item">
                        <p class="warranty__btn--recommended">recomendado</p>
                        <li><input class="table-warranty__radio js-warranty-one-year" name="ge-warranty" type="radio" id="one-year-warranty"></li>
                        <li>
                            <label for="one-year-warranty" class="warranty__title--center">mais 1 ano <br> de garantia</label>
                            <p class="warranty__text--box-space">após o término<br> da garantia do fabricante</p>
                        </li>
                    </ul>
                    <ul class="table-warranty__options--last table-warranty__none">
                        <li><input class="table-warranty__radio js-warranty-two-years" name="ge-warranty" type="radio" id="two-year-warranty"></li>
                        <li>
                            <label for="two-year-warranty" class="warranty__title--center">mais 2 anos <br> de garantia</label>
                            <p class="warranty__text--box-space">após o término<br> da garantia do fabricante</p>
                        </li>
                    </ul>
                </div>
                <table class="table-warranty__text">
                    <tbody><tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">valor da garantia</td>
                        <td class="table-warranty__td-space">...</td>
                        <td class="table-warranty__td-txt--blue"><span class="js-warranty-parcel-quantity">10</span>x <span class="js-warranty-one-parcel-price">R$ 6,56</span> sem juros</td>
                        <td class="table-warranty__td-txt--blue table-warranty__none"><span class="js-warranty-parcel-quantity">10</span>x <span class="js-warranty-two-parcel-price">R$ 9,33</span> sem juros</td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">consertos utilizando peças genuínas</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">mais de 3 mil assistências técnicas em todo o Brasil</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-no"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">mais tempo de garantia além do fabricante</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-no"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">concorra a R$ 5.000,00 durante 3 meses</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-no"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                </tbody></table>
            </div>
        </div>
        <div class="table-warranty js-warranty-TC none">
                        <div class="js-control-coluns">
                <div class="table-warranty__description">
                    <img src="../dist/desktop/index_files/logo_troca-certa-91862327.png">
                    <div class="table-warranty__text">
                        Seu produto apresentou defeito?<br> Deixe com a gente! Seu <strong>Seguro de Garantia Estendida Original</strong> troca seu produto com defeito por um produto novo!
                    </div>
                </div>
                <div class="table-warranty__box">
                    <ul class="table-warranty__options">
                        <li><input class="table-warranty__radio without-warranty" checked="checked" name="tc-warranty" type="radio"></li>
                        <li>
                            <p class="warranty__title--center">sem troca<br> certa</p> <p class="warranty__text--box-option">somente garantia<br> do fabricante</p>
                        </li>
                    </ul>
                    <ul class="table-warranty__options--item">
                        <p class="warranty__btn--recommended">recomendado</p>
                        <li><input class="table-warranty__radio js-warranty-one-year" name="tc-warranty" type="radio"></li>
                        <li>
                            <p class="warranty__title--center">1 ano de <br>troca certa</p> <p class="warranty__text--box-space">após o término<br> da garantia do fabricante</p>
                        </li>
                    </ul>
                    <ul class="table-warranty__options--last table-warranty__none">
                        <li><input class="table-warranty__radio js-warranty-two-years" name="tc-warranty" type="radio"></li>
                        <li>
                            <p class="warranty__title--center">2 anos de<br> troca certa</p> <p class="warranty__text--box-space">após o término<br> da garantia do fabricante</p>
                        </li>
                    </ul>
                </div>
                <table class="table-warranty__text">
                    <tbody><tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">valor da garantia</td>
                        <td class="table-warranty__td-space">...</td>
                        <td class="table-warranty__td-txt--blue"><span class="js-warranty-parcel-quantity">10</span>x <span class="js-warranty-one-parcel-price">R$ 6,56</span> sem juros</td>
                        <td class="table-warranty__td-txt--blue table-warranty__none"><span class="js-warranty-parcel-quantity">10</span>x <span class="js-warranty-two-parcel-price">R$ 9,33</span> sem juros</td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">seu produto quebrou? troque por um novo</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-no"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">mais tempo de sossego além da garantia do fabricante</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-no"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                    <tr class="table-warranty__tr">
                        <td class="table-warranty__td-first">concorra a R$ 5.000,00 durante 3 meses</td>
                        <td class="table-warranty__td-space"><i class="warranty__sprite--icon-no"></i></td>
                        <td class="table-warranty__td-txt"><i class="warranty__sprite--icon-ok"></i></td>
                        <td class="table-warranty__td-txt table-warranty__none"><i class="warranty__sprite--icon-ok"></i></td>
                    </tr>
                </tbody></table>
            </div>
        </div>
        <div class="price-warranty">
                        <p class="price-warranty__total"><span style="color:#404040">Subtotal:</span> <span class="subtotal">R$ '. $preco .'</span>  à vista </p>
            <p class="price-warranty__txt">ou em até 10x de <span class="subtotalParcelPrice">R$ '.$precodez.'</span> sem juros</p>
            <span class="price-warranty__accept none">Ao clicar em continuar você aceita as condições do Seguro
            <a data-href="/produto/roubo-e-furto-qualificado/" data-size="760x400" data-options="{&quot;modal&quot;:true, &quot;position&quot;:&quot;center&quot;}" class="ml-imframebox warranty__link warranty__link-protection none ml-iframebox-click-ready">Roubo e Furto</a><span class="js-warranty-period none">,</span>
            <a data-href="/produto/garantia-estendida/" data-size="760x400" data-options="{&quot;modal&quot;:true, &quot;position&quot;:&quot;center&quot;}" class="ml-imframebox warranty__link none warranty__link-extend ml-iframebox-click-ready">Garantia Estendida</a>
            e a <a class="ml-imframebox warranty__link ml-iframebox-click-ready" data-href="/produto/garantia-formas-pagamento/" data-size="500x250" data-options="{&quot;modal&quot;:true, &quot;position&quot;:&quot;center&quot;}">forma de pagamento</a></span>
            <a href="sacola.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'" class="price-warranty__btn--continue btn-buy-warranty">continuar</a>
        </div>
        <div class="recomend-warranty">
            <p class="recomend-warranty__title">Eles aprovaram! Confira a história de quem já usou:</p>
            <ul class="recomend-warranty__text">
                <li class="recomend-warranty__txt">Maria do Socorro Siqueira</li>
                <li class="font-sixteen">Suzano/SP</li>
                <li class="warranty__sprite--icon-star"></li>
                <li class="warranty__text--comments">Eu não conhecia a Garantia Estendida. Foi uma maravilha! Nunca mais vou comprar nada sem Garantia Estendida. As pessoas que estão na dúvida, aconselho a fazer a mesma coisa que eu fiz! De repente quebra, como a minha geladeira quebrou, como você vai fazer? Não existe coisa melhor do que a Garantia Estendida.</li>
                <li><i class="warranty__sprite--icon-marks"></i></li>
            </ul>
            <ul class="recomend-warranty__text">
                <li class="recomend-warranty__txt">Edileuza</li>
                <li class="font-sixteen">Guarulhos</li>
                <li class="warranty__sprite--icon-star"></li>
                <li class="warranty__text--comments">Obrigada pelo seu atendimento, quero dizer que o seguro está de parabéns pelo atendimento excelente, Não é em todos os lugares que acontece isso.</li>
                <li><i class="warranty__sprite--icon-marks"></i></li>
            </ul>
            <ul class="recomend-warranty__text--last">
                <li class="recomend-warranty__txt">José</li>
                <li class="font-sixteen">Suzano/SP</li>
                <li class="warranty__sprite--icon-star"></li>
                <li class="warranty__text--comments">O aparelho a gente compra e não sabe quando dá defeito, e as vezes dá defeito e a gente não tem dinheiro pra comprar outro. Garantia estendida vale a pena ter!</li>
                <li><i class="warranty__sprite--icon-marks"></i></li>
            </ul>
        </div>
        <div class="repair-warranty">
            <p class="recomend-warranty__title--repair">Você sabe quanto custa consertar seu produto?</p>
            <p class="font-sixteen">Compare com os custos abaixo e veja como vale a pena!</p>
            <ul class="repair-warranty__text">
                <li class="warranty__title--product">Celular</li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Mão de obra</p> <strong>R$ 120,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Placa Principal</p> <strong>R$ 432,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Tela touch</p> <strong>R$ 504,00</strong>
                </li>
            </ul>
            <ul class="repair-warranty__text">
                <li class="warranty__title--product">Computador</li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Mão de obra</p> <strong>R$ 120,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Memória RAM</p> <strong>R$ 192,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Drive DVD</p> <strong>R$ 228,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Placa Principal</p> <strong>R$ 336,00</strong>
                </li>
            </ul>
            <ul class="repair-warranty__text--last">
                <li class="warranty__title--product">Televisor LCD/LED</li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Mão de obra</p> <strong>R$ 200,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Painel (tela)</p> <strong>R$ 1.440,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Placa Fonte</p> <strong>R$ 540,00</strong>
                </li>
                <li class="repair-warranty__info">
                    <p class="repair-warranty__item">Placa Principal</p> <strong>R$ 576,00</strong>
                </li>
            </ul>
        </div>
        <span data-href="https://d25zlb44gqlazw.cloudfront.net/static/img/default/warranty/tabela_custo_reparos-5b5c41a7.jpg" data-options="{&quot;modal&quot;:true, &quot;position&quot;:&quot;center&quot;}" class="btn-mgl ml-imframebox btn-blue big-xs color-white font-twenty-one btn-repair-cost-popup warranty-complete-table ml-iframebox-click-ready" data-size="925x650">
                                veja a tabela completa de custos e reparos
        </span>
        <div class="motives-warranty">
            <p class="recomend-warranty__title--motive">Precisa de mais motivos? Temos mais alguns!</p>
            <ul>
                <li class="motives-warranty__item"><i class="warranty__sprite--icon-more"></i> Mais segurança para comprar produtos de qualquer marca</li>
                <li class="motives-warranty__item"><i class="warranty__sprite--icon-more"></i>
                    <a data-href="/produto/garantia-estendida-helpdesk/" title="Help Desk 24h, 7 dias por semana" data-options="{&quot;modal&quot;:true, &quot;position&quot;:&quot;center&quot;}" data-size="750x415" class="ml-imframebox warranty__link ml-iframebox-click-ready">Lu Ajuda 24h, 7 dias na semana</a>
                </li>
                <li class="motives-warranty__item"><i class="warranty__sprite--icon-more"></i> Central de atendimento exclusiva</li>
                <li class="motives-warranty__item"><i class="warranty__sprite--icon-more"></i> Seguradora própria (Luizaseg)</li>
                <li class="motives-warranty__item"><i class="warranty__sprite--icon-more"></i> E ainda! Concorra a sorteios de R$5 mil durante 3 meses</li>
            </ul>
        </div>




        <div class="regulation-warranty">
            <a href="https://d25zlb44gqlazw.cloudfront.net/v0/pdf/guia_boas_praticas_garantia_estendida.pdf" class="warranty__link--guide" target="_blank">
                <i class="warranty__sprite--icon-pdf"></i>
                <span class="regulation-warranty__guide"><strong>guia de boas práticas</strong> do seguro de garantia estendida original</span>
            </a>
            <p class="regulation-warranty__attention"><strong>Atenção pessoas jurídicas:</strong> o seguro de garantia estendida original não pode ser adquirido por empresas</p>

            <p class="regulation-warranty__text js-warranty-RF">
                                Seguro Roubo/Furto Qualificado + Quebra Acidental, Processo Susep nº15414.900738/2014-98, garantido pela Cardif do Brasil Seguros e Garantias, CNPJ: 08.279.191/0001-84,  rua Campos Bicudo, 98, 1º ao 5º andar, Itaim Bibi, São Paulo, CEP 04536-010. Site: <a target="_blank" href="http://www.bnpparibascardif.com.br/">www.bnpparibascardif.com.br</a>. Franquia Roubo e Furto Qualificado: 20% com mínimo de R$ 20,00, sobre o Limite Máximo da Indenização e Quebra Acidental: 20% sobre o valor do reparo ou sobre Limite Máximo da Indenização em caso de Troca. Seguro de Garantia Estendida Original, Processo Susep nº 15414.900276/2014-17, garantido pela Luizaseg Seguros S/A, Rua Campos Bicudo, 98, 3º andar, Itaim Bibi, São Paulo, CEP 04536-010. Site: <a target="_blank" href="https://www.magazineluiza.com.br/produto/garantia-plus/www.luizaseg.com.br">www.luizaseg.com.br</a>. Representante de seguro: Magazine Luiza S/A, CNPJ nº 47.960.950/0001-21. Corretora: Viotto Corretora de Seguros e Previdência LTDA., CNPJ nº 56.170.061/0001-51, e Processo Susep nº 05892610059706. O segurado poderá consultar a situação cadastral do seu corretor de seguros no site <a target="_blank" href="http://www.susep.gov.br/">www.susep.gov.br</a>, por meio de seu registro na SUSEP, nome completo, CNPJ ou CPF. "A contratação de seguro é opcional, sendo possível a desistência do contrato em até 7 (sete) dias corridos com a devolução integral do valor pago." "É proibido condicionar desconto no preço do bem à aquisição do seguro." "A comercialização de seguro é fiscalizada pela Susep. <a target="_blank" href="http://www.susep.gov.br/">www.susep.gov.br</a> - 0800 021 8484 "A aprovação do Plano pela Susep não implica, por parte da Autarquia, em incentivo ou recomendação à sua aquisição. Caso não esteja satisfeito com a resposta fornecida pelo SAC, entre em contato com a Ouvidoria : 0800 727 2482 - Dias úteis, das 9h as 18 horas (horário de Brasília) exceto feriados ou <a target="_blank" href="http://www.bnpparibascardif.com.br/pid2094/ouvidoria.html">ouvidoria.bnpparibascardif.com.br</a>
            </p>
            <p class="regulation-warranty__text none js-warranty-TC">
                                O Troca Certa é o nome comercial do Seguro de Garantia Estendida Original, para bens eletroportáteis cujo valor de comercialização seja de até R$ 600,00 (seiscentos reais) e celulares e smartphones cujo valor de comercialização seja de até R$ 300,00, e é garantido por Luizaseg Seguros S/A , CNPJ: 07.746.953/0001-42, com sede na Rua Campos Bicudo, 98 – 1º ao 5º andar, São Paulo, CEP:04536-010, <a target="_blank" href="http://www.luizaseg.com.br/">www.luizaseg.com.br</a>, Processo Susep 15414.900276/2014-17. Representante de seguro: Magazine Luiza S/A, CNPJ 47.960.950/0001-21. Corretora Viotto Corretora de Seguros e Previdência LTDA, CNPJ 56.170.061/0001-51, Registro Susep: 10.0059706. Orientamos a leitura das condições gerais do seguro, disponibilizadas neste site. Capitalização: Cardif Capitalização S.A. CNPJ: 11.467.788/0001-67 Processo SUSEP: 15414.000312/2010-17. Modalidade: Incentivo. Período da Promoção: 3 meses. Sorteios Mensais. Consulte o regulamento no link regulamentos.bnpparibascardif.com.br. Assistência Help Desk CDF – Central de Funcionamento Tecnologia e Participações S.A, CNPJ 08.769.874/0001-10. Condições Gerais: assistencias.bnpparibascardif.com.br. "A contratação de seguro é opcional, sendo possível a desistência do contrato em até 7 (sete) dias corridos com a devolução integral do valor pago." "É proibido condicionar desconto no preço do bem à aquisição do seguro." "A comercialização de seguro é fiscalizada pela Susep. <a target="_blank" href="http://www.susep.gov.br/">www.susep.gov.br</a> - 0800 021 8484". "A aprovação do Plano pela Susep não implica, por parte da Autarquia, em incentivo ou recomendação à sua aquisição." "É proibida a venda de títulos de capitalização a menores de dezesseis ano - Art.3º, I do Código Civil". Caso não esteja satisfeito com a resposta fornecida pelo SAC 0800 545 4040, entre em contato com a Ouvidoria : 0800 727 2482 - Dias úteis, das 9h as 18 horas (horário de Brasilia) exceto feriados ou <a target="_blank" href="http://www.bnpparibascardif.com.br/pid2094/ouvidoria.html">ouvidoria.bnpparibascardif.com.br</a>
            </p>
            <p class="regulation-warranty__text js-warranty-GE none">
                                Seguro de Garantia Estendida Original, Processo Susep nº15414.900276/2014-17, garantido pela Luizaseg Seguros S/A, Rua Campos Bicudo, 98, 3º andar, Itaim Bibi, São Paulo, CEP 04536-010. Site: <a target="_blank" href="http://www.luizaseg.com.br/">www.luizaseg.com.br</a>. Representante de seguro: Magazine Luiza S/A, CNPJ nº47.960.950/0001-21. Corretora: Viotto Corretora de Seguros e Previdência LTDA., CNPJ nº 56.170.061/0001-51, e Processo Susep nº 05892610059706. O segurado poderá consultar a situação cadastral do seu corretor de seguros no site <a target="_blank" href="http://www.susep.gov.br/">www.susep.gov.br</a>, por meio de seu registro na SUSEP, nome completo, CNPJ ou CPF. "A contratação de seguro é opcional, sendo possível a desistência do contrato em até 7 (sete) dias corridos com a devolução integral do valor pago." "É proibido condicionar desconto no preço do bem à aquisição do seguro." "A comercialização de seguro é fiscalizada pela Susep. <a target="_blank" href="http://www.susep.gov.br/">www.susep.gov.br</a> - 0800 021 8484 "A aprovação do Plano pela Susep não implica, por parte da Autarquia, em incentivo ou recomendação à sua aquisição. Caso não esteja satisfeito com a resposta fornecida pelo SAC, entre em contato com a Ouvidoria : 0800 727 2482 - Dias úteis, das 9h as 18 horas (horário de Brasília) exceto feriados ou <a target="_blank" href="http://www.bnpparibascardif.com.br/pid2094/ouvidoria.html">ouvidoria.bnpparibascardif.com.br</a>
            </p>
        </div>



    </div>
    <div id="adx" class="centralizer-adx">
        <div class="adx-wrapper-middle"></div>
    </div>
</div>
                    </div>
                </div>
            </div>
            <footer class="footer-wrapper-checkout">
    <div class="fc-stamps-container">
                <a href="http://www.internetsegura.org/" target="_blank" title="Internet Segura" class="fc-stamp-internet-segura">Internet Segura</a>
        <a href="https://www.magazineluiza.com.br/especiais/ebit/" target="_blank" title="E-Bit" class="fc-stamp-ebit">E-Bit</a>
        <a href="https://www.magazineluiza.com.br/estaticas/seguranca-maxima/" target="_blank" title="Segurança máxima" class="fc-stamp-seguranca-maxima">Segurança máxima</a>
        <span class="fc-pipe"></span>
        <span class="mastercard" title="Mastercard">Mastercard</span>
        <span class="visa" title="Visa">Visa</span>
        <span class="americanexpress" title="American Express">American Express</span>
        <span class="dinners" title="Diners">Diners</span>
        <span class="cartaoLuiza" title="Cartão Luiza Mastercard Preferêncial e Cartão Luiza Mastercard Ouro">Cartão Luiza Mastercard Preferêncial e Cartão Luiza Mastercard Ouro</span>
                        <span class="boleto" title="Boleto Bancário">Boleto Bancário</span>
                <span class="hipercard" title="Hipercard">Hipercard</span>
        <span class="elo" title="Cartão Elo">Elo</span>
        <span class="aura" title="Cartão Aura">Aura</span>
    </div>
        <p>A sacola de compras apenas armazena a sua lista de produtos. A reserva de cada produto é garantida por até 15 minutos quando você chega na página de pagamento.</p>
    <p>Rodovia dos Bandeirantes KM 68,760 - Rio Abaixo - CEP:13213-902 - Louveira/SP - CNPJ: 47960950/0449-27</p>
    <p>Preços e condições de pagamento exclusivos para compras via internet. Ofertas válidas até o término de nossos estoques para internet. Vendas sujeitas à análise e confirmação de dados.</p>
    <p>® 2012 Magazine Luiza – Todos os direitos reservados</p>
</footer>
</body></html>',
    $conteudo);
echo $substituicao;


?>