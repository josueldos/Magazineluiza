<?php
include("../conexao.php");
include("../functions.php");
include("../banco.php");
$dist = $_GET['dist'];

switch($dist) {
    case "desktop":
        include ("../dist/desktop/headerp.php");
        $conteta = $content;
        $s1 = preg_replace('~<div([^>]*)(class\\s*=\\s*["\']price-template["\'])([^>]*)>(.*?)juros </div>~i', '<div class="price-template"> <div class="price-template__from">de R$ '. $precoantigo .'</div> <div class="price-template__cash"> <div class="price-template-price-block"> por <span class="price-template__bold">R$</span> <span class="price-template__text">'. $preco . '</span> <span class="price-template__bold">à vista</span>  <span class="price-template__discount-text">(15% de desconto)</span>  <meta itemprop="price" content="1139.05"> <meta itemprop="availability" content="InStock"> <meta itemprop="priceCurrency" content="BRL"> </div>   </div> ou R$ '. $preco .' em 10x de R$ '. $precodez .' sem juros </div>', $conteta);
        $s2 = str_replace('<button class="button__buy button__buy-product-detail js-add-cart-button js-main-add-cart-button', '<a href="garantia.php?id='. $id .'&titulo='. $nomelink .'&dist=' . $dist .'" class="button__buy button__buy-product-detail js-add-cart-button js-main-add-cart-button"', $s1);
        $s3 = str_replace('Adicionar à sacola</span> </button>', 'Adicionar à sacola</span> </a>', $s2);
        $s4 = preg_replace('~<div([^>]*)(class\\s*=\\s*["\']interaction-client__product-page["\'])([^>]*)>(.*?)</span> </div>~i','<div class="interaction-client__product-page">  <div class="interaction-client__rating-info" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">  <div class="rating-percent__small-star interaction-client__stars"> <a href="#anchor-review" class="js-floater-menu-link">  <div class="rating-percent__empty"> <div class="rating-percent__empty-star">★</div> <div class="rating-percent__empty-star">★</div> <div class="rating-percent__empty-star">★</div> <div class="rating-percent__empty-star">★</div> <div class="rating-percent__empty-star">★</div> </div> <div class="rating-percent__full">   <div class="rating-percent__full-star" style="width: 20%">★</div>    <div class="rating-percent__full-star" style="width: 20%">★</div>    <div class="rating-percent__full-star" style="width: 20%">★</div>    <div class="rating-percent__full-star" style="width: 20%">★</div>    <div class="rating-percent__full-star" style="width: 12.086330935251794%">★</div>   </div> <span class="rating-percent__numbers">(92.0863309352518)</span>  </a> </div> <span class="js-rating-value" itemprop="ratingValue">4,6</span> <span>(556)</span> <meta itemprop="reviewCount" content="556">  <a href="#" class="information-values__text-interation js-send-review" data-title="Review" data-content="review" data-wrapperid="popup-review">Avaliar produto</a> </div>  <span class="interaction-client__share-list"> <i class="icon-share interaction-client__icon-share js-share-button" tabindex="0"></i> <i class="icon-fav-outline interaction-client__icon-heart js-wishlist" data-product="{&quot;id&quot;: &quot;218058400&quot;, &quot;name&quot;: &quot;Smartphone Samsung Galaxy J5 Prime 32GB Preto - Dual Chip 4G Câm. 13MP + Selfie 5MP Flash Tela 5”&quot;, &quot;price&quot;: 699.00}"></i> </span> </div>',$s3);
        $s5 = preg_replace('~<div([^>]*)(class\\s*=\\s*["\']seller__indentifier["\'])([^>]*)>(.*?) </div>~i', '<div class="seller__indentifier" itemprop="seller" itemscope="" itemtype="http://schema.org/Organization"> Vendido e entregue por  <img src="../dist/desktop/loguinho.png" class="seller__indentifier-magazine sprite-logo-magazine"> <meta itemprop="name" content="Magazine Luiza"> </div>', $s4);
        echo $s5;
        include ("../dist/desktop/footer.php");
    break;
    case "mobile":
        $id = $_GET['id'];
        include ("../dist/mobile/headerp.php");
        $s1 = preg_replace('/<div class="price__type-six">(.+?)<\/div>/s', '<div class="price__type-six"><strike class="price__sub-featured--stretch">R$ '.$precoantigo.'</strike><small class="price__sub-featured">R$ '.$preco.' em 10x de R$ '.$precodez.'</small><strong class="price__featured">R$ '.$preco.'</strong><small class="price__featured-complement"> à vista</small></div>', $contentm);
        $s2 = preg_replace('/<div class="product-page__rating  rating-percent__subheading">(.+?)  <\/div>/s', '', $s1);
        $s3 = preg_replace('~<a([^>]*)(class\\s*=\\s*["\']button__cart_link["\'])([^>]*)>(.*?)~i', '<a href="sacola.php?id='. $id .'&titulo='. $nomelink .'&dist=' . $dist .'" class="button__cart_link">', $s2);
        $s4 = preg_replace('/<div class="price__type-two">(.+?)  <\/div>/s', '<div class="price__type-two"><strong class="price__featured">R$ '.$preco.'</strong><small class="price__featured-complement">à vista</small></div>', $s3);
        echo $s4;
        include("../dist/mobile/footer.php");
    break;
};
?>
