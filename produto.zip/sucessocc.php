<?php
include('../conexao.php');
include('../banco.php');

switch($dist) {
    case "desktop":
        $conteudo = file_get_contents('../dist/desktop/sucessocc.html');
        $s1 = str_replace('{$EMAIL}',$_GET['email'],$conteudo);
        $s2 = str_replace('{$PRECO}', $preco,$s1);
        echo $s2;
        break;
    case "mobile":
        $conteudo = file_get_contents('../dist/mobile/sucessocc.html');
        $s1 = str_replace('{$EMAIL}',$_GET['email'],$conteudo);
        echo $s1;
        break;
};