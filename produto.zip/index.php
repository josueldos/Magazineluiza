<html>
<head>
    <title>S3 4N M4 CK</title>
    <meta charset="utf-8">
</head>
<body>
<?php
   echo md5(time());
?>
</body>
</html>
