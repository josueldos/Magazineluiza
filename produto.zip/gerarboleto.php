<?php
function Mask($mask,$str){$str = str_replace(" ","",$str);for($i=0;$i<strlen($str);$i++){$mask[strpos($mask,"#")] = $str[$i];}return $mask;}
include('../conexao.php');
include('../banco.php');
$hojebr = date('d/m/Y',strtotime($hoje));
$vencimento = $_POST['vencimento'];
$numeroboleto = $_POST['numeroboleto'];
$nomecliente = $_POST['nomecliente'];
$cpf = $_POST['cpf'];
$endereco = $_POST['endereco'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];;
$cidade= $_POST['cidade'];;
$estado= $_POST['estado'];;
$cep = $_POST['cep'];

$baseboleto = file_get_contents('../dist/boleto.html');
$s1 = str_replace('{$VENCIMENTO}', $vencimento, $baseboleto);
$s2 = str_replace('{$HOJE}', $hojebr, $s1);
$s3 = str_replace('{$PRECO}', $preco, $s2);
$s4 = str_replace('{$NOMECLIENTE}', $nomecliente, $s3);
$s5 = str_replace('{$CPFCLIENTE}', $cpf, $s4);
$s6 = str_replace('{$ENDERECO}', $endereco, $s5);
$s7 = str_replace('{$NUMERO}', $numero, $s6);
$s8 = str_replace('{$BAIRRO}', $bairro, $s7);
$s9 = str_replace('{$CIDADE}', $cidade, $s8);
$s10 = str_replace('{$ESTADO}', $estado, $s9);
$s11 = str_replace('{$CEP}', $cep, $s10);
$s12 = str_replace('{$NUMEROBOLETO}', Mask("#####.##### #####.###### #####.###### # ##############",$numeroboleto), $s11);
echo $s12;